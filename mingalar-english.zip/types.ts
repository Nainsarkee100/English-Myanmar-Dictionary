
export type View = 'home' | 'dictionary' | 'grammar' | 'tutor' | 'quiz' | 'notes';

export interface DictionaryResult {
  word: string;
  partOfSpeech?: 'noun' | 'verb' | 'adj' | 'adv' | 'prep' | 'conj' | 'pronoun' | 'interj';
  phonetic: string;
  myanmarMeaning: string;
  definition: string;
  examples: string[];
  synonyms: string[];
  isOffline?: boolean;
}

export interface PracticeQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface GrammarLesson {
  id: string;
  title: string;
  category: 'Structure' | 'Tenses' | 'Parts of Speech' | 'Advanced' | 'Writing';
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  description: string;
  explanation: string;
  summary: string;
  myanmarExplanation: string;
  examples: { 
    english: string; 
    myanmar: string; 
  }[];
  commonMistakes: { 
    wrong: string; 
    right: string; 
    reason: string; 
  }[];
  tips: string[];
  practice: PracticeQuestion[];
  relatedQuizLevel?: number;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

export interface QuizLevel {
  level: number;
  questions: QuizQuestion[];
}

export interface ActivityEntry {
  type: 'grammar' | 'quiz' | 'word';
  id: string;
  label: string;
  timestamp: string;
  score?: number;
}

export type FontSize = 'small' | 'medium' | 'large' | 'extra-large';

export interface AccessibilitySettings {
  fontSize: FontSize;
  highContrast: boolean;
}

export interface UserProgress {
  wordsLearned: number;
  streak: number;
  lastActive: string;
  grammarCompleted: string[];
  quizLevelsCompleted: number[];
  quizScores: Record<number, number>; // Level number -> Best Score
  totalPoints: number;
  history: ActivityEntry[];
  version: number;
  accessibility?: AccessibilitySettings;
}

export interface UserNote {
  id: string;
  title: string;
  content: string;
  timestamp: string;
}
