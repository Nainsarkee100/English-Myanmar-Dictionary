
import React, { useState, useRef, useEffect } from 'react';
import { chatWithTutor } from '../services/geminiService';
import { Message } from '../types';

export default function AITutor() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      text: "Mingalaba! I am your AI English Tutor. How can I help you today? Ask me about grammar, words, or practice conversation!",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRetrying, setIsRetrying] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const update = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading || !isOnline) return;

    const userMsg: Message = { role: 'user', text: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);
    setIsRetrying(false);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      
      const response = await chatWithTutor(history, input);
      setMessages(prev => [...prev, {
        role: 'model',
        text: response || "I didn't quite catch that.",
        timestamp: new Date()
      }]);
    } catch (err: any) {
      let fallbackText = "The signal is a bit weak here. Let's try again in a moment!";
      
      if (err.message === "KEY_RESET_REQUIRED") {
        fallbackText = "It looks like I need to reconnect to my brain. Please try re-selecting your API key or refreshing the app.";
        // Trigger platform key selection if available
        if (window.aistudio?.openSelectKey) {
          window.aistudio.openSelectKey();
        }
      } else if (err.message === "TIMEOUT_ERROR") {
        fallbackText = "Connection timed out. Please check your internet signal and try again.";
      }

      setMessages(prev => [...prev, {
        role: 'model',
        text: fallbackText,
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
      setIsRetrying(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto h-[calc(100vh-12rem)] py-4 flex flex-col px-4">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-black text-slate-800">Practice with AI</h2>
        <div className={`mt-1 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${isOnline ? 'bg-green-100 text-green-600' : 'bg-amber-100 text-amber-600'}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-green-500' : 'bg-amber-500 animate-pulse'}`}></span>
          {isOnline ? 'AI Connected' : 'AI Offline Mode'}
        </div>
      </div>

      <div className="flex-1 bg-white rounded-[2rem] shadow-2xl overflow-hidden flex flex-col border border-slate-50 relative">
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar bg-slate-50/20">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] px-5 py-3 rounded-2xl shadow-sm ${
                m.role === 'user' 
                ? 'bg-indigo-600 text-white rounded-br-none' 
                : 'bg-white text-slate-700 border border-slate-100 rounded-bl-none'
              }`}>
                <p className="text-sm font-medium whitespace-pre-wrap leading-relaxed">{m.text}</p>
                <p className="text-[8px] font-black mt-2 tracking-widest uppercase opacity-40">
                  {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex flex-col items-start gap-2">
              <div className="bg-white border border-slate-100 px-5 py-3 rounded-2xl flex gap-1">
                <div className="w-1.5 h-1.5 bg-indigo-300 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-indigo-300 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-1.5 h-1.5 bg-indigo-300 rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
              {isRetrying && <p className="text-[8px] font-black uppercase text-indigo-400 ml-2 tracking-widest animate-pulse">Retrying signal...</p>}
            </div>
          )}
        </div>

        {!isOnline && (
          <div className="absolute inset-0 z-50 bg-white/80 backdrop-blur-sm flex items-center justify-center p-8 text-center">
            <div className="max-w-xs animate-in zoom-in duration-300">
              <div className="text-5xl mb-4">📡</div>
              <h3 className="text-xl font-black text-slate-900 mb-2">AI is Sleeping</h3>
              <p className="text-slate-500 font-medium mb-6">Connect to the internet to talk with Mingalar. Your offline lessons are still available!</p>
              <button 
                onClick={() => window.location.reload()}
                className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-indigo-100 active:scale-95 transition-all"
              >
                Check Signal
              </button>
            </div>
          </div>
        )}

        <form onSubmit={handleSend} className="p-4 bg-white border-t border-slate-100 flex gap-3">
          <input
            type="text"
            value={input}
            disabled={!isOnline || isLoading}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isOnline ? "Ask a question..." : "AI Unavailable Offline"}
            className="flex-1 px-5 py-4 rounded-xl border-2 border-slate-50 bg-slate-50 focus:bg-white focus:border-indigo-500 outline-none transition-all font-medium disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading || !isOnline}
            className="bg-slate-900 text-white w-14 h-14 rounded-xl flex items-center justify-center hover:bg-indigo-700 transition-all disabled:bg-slate-100 active:scale-95 shadow-xl shadow-slate-200"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
          </button>
        </form>
      </div>
    </div>
  );
}
