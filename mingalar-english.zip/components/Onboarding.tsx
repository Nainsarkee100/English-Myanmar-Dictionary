
import React, { useState } from 'react';

interface OnboardingProps {
  onComplete: () => void;
}

const slides = [
  {
    title: "Mingalaba!",
    description: "Welcome to Mingalar English. Your personal journey to mastering English starts here.",
    icon: "🇲🇲",
    color: "from-indigo-600 to-indigo-800",
    tips: ["Learn at your own pace", "Track your progress", "Daily practice is key"]
  },
  {
    title: "Offline Learning",
    description: "No internet? No problem. Our dictionary and grammar lessons work 100% offline.",
    icon: "📡",
    color: "from-emerald-600 to-emerald-800",
    tips: ["5000+ words pre-indexed", "Grammar lessons stored locally", "Save data everywhere"]
  },
  {
    title: "Roadmap to Fluency",
    description: "Follow a structured path. Master grammar topics and test yourself with levels.",
    icon: "🎯",
    color: "from-orange-500 to-orange-700",
    tips: ["Complete missions", "Earn XP points", "Unlock new challenges"]
  },
  {
    title: "AI Power",
    description: "When online, talk to Mingalar AI. Ask questions or just practice conversation.",
    icon: "🤖",
    color: "from-slate-800 to-slate-950",
    tips: ["Ask about grammar", "Get instant help", "Friendly tutoring anytime"]
  }
];

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onComplete();
    }
  };

  const slide = slides[currentSlide];

  return (
    <div className="fixed inset-0 z-[200] bg-white flex flex-col overflow-hidden">
      <div className={`flex-1 flex flex-col items-center justify-center p-8 transition-colors duration-700 bg-gradient-to-br ${slide.color} text-white`}>
        <div className="w-full max-w-sm flex flex-col items-center animate-in zoom-in-95 duration-500">
          <div className="text-9xl mb-12 drop-shadow-2xl">{slide.icon}</div>
          <h2 className="text-4xl font-black mb-4 text-center">{slide.title}</h2>
          <p className="text-indigo-100 text-lg text-center leading-relaxed mb-12">
            {slide.description}
          </p>

          <div className="w-full space-y-3">
            {slide.tips.map((tip, i) => (
              <div key={i} className="flex items-center gap-3 bg-white/10 p-4 rounded-2xl border border-white/5">
                <span className="text-emerald-400 font-black">✓</span>
                <span className="text-sm font-bold opacity-90">{tip}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-8 pb-12 bg-white flex flex-col items-center">
        <div className="flex gap-2 mb-8">
          {slides.map((_, i) => (
            <div 
              key={i} 
              className={`h-2 rounded-full transition-all duration-300 ${i === currentSlide ? 'w-8 bg-indigo-600' : 'w-2 bg-slate-200'}`}
            />
          ))}
        </div>

        <div className="w-full max-w-sm flex gap-4">
          {currentSlide > 0 && (
            <button 
              onClick={() => setCurrentSlide(currentSlide - 1)}
              className="px-6 py-5 rounded-[2rem] font-black text-slate-400 hover:text-slate-600 transition-all"
            >
              Back
            </button>
          )}
          <button 
            onClick={handleNext}
            className="flex-1 bg-indigo-600 text-white py-5 rounded-[2rem] font-black shadow-2xl active:scale-95 transition-all text-xl"
          >
            {currentSlide === slides.length - 1 ? 'Get Started' : 'Next Step'}
          </button>
        </div>
      </div>
    </div>
  );
}
