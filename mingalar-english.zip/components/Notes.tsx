import React, { useState, useEffect } from 'react';
import { getNotes, saveNote, deleteNote } from '../services/storage';
import { UserNote } from '../types';

export default function Notes() {
  const [notes, setNotes] = useState<UserNote[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [currentNote, setCurrentNote] = useState({ title: '', content: '' });

  useEffect(() => {
    setNotes(getNotes());
  }, []);

  const handleSave = () => {
    if (!currentNote.title || !currentNote.content) return;
    const newNote: UserNote = {
      id: Date.now().toString(),
      title: currentNote.title,
      content: currentNote.content,
      timestamp: new Date().toLocaleDateString()
    };
    saveNote(newNote);
    setNotes(getNotes());
    setCurrentNote({ title: '', content: '' });
    setIsEditing(false);
  };

  return (
    <div className="max-w-2xl mx-auto py-6 px-4 pb-20">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-black">My Learning Notes</h1>
        <button 
          onClick={() => setIsEditing(!isEditing)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold shadow-lg shadow-indigo-100 active:scale-95 transition-all"
        >
          {isEditing ? 'Cancel' : '+ New Note'}
        </button>
      </div>

      {isEditing && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200 mb-8 animate-in slide-in-from-top-4 duration-300">
          <input
            type="text"
            placeholder="Topic (e.g. Present Tense)"
            value={currentNote.title}
            onChange={e => setCurrentNote({...currentNote, title: e.target.value})}
            className="w-full mb-4 px-4 py-3 rounded-xl border border-slate-100 focus:border-indigo-500 outline-none font-bold"
          />
          <textarea
            placeholder="Write your notes here..."
            value={currentNote.content}
            onChange={e => setCurrentNote({...currentNote, content: e.target.value})}
            className="w-full h-32 px-4 py-3 rounded-xl border border-slate-100 focus:border-indigo-500 outline-none mb-4 resize-none"
          />
          <button 
            onClick={handleSave}
            className="w-full bg-slate-900 text-white py-4 rounded-xl font-black active:scale-95 transition-all"
          >
            Save Note Locally
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4">
        {notes.map(note => (
          <div key={note.id} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm group">
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-bold text-lg">{note.title}</h3>
              <button 
                onClick={() => { deleteNote(note.id); setNotes(getNotes()); }}
                className="opacity-0 group-hover:opacity-100 text-red-400 text-xs font-bold transition-all"
              >
                Delete
              </button>
            </div>
            <p className="text-slate-600 text-sm whitespace-pre-wrap mb-4">{note.content}</p>
            <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{note.timestamp}</span>
          </div>
        ))}
        {notes.length === 0 && !isEditing && (
          <div className="text-center py-20 bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl">
            <p className="text-slate-400 font-medium">Your notebook is empty. Start writing down what you learn!</p>
          </div>
        )}
      </div>
    </div>
  );
}