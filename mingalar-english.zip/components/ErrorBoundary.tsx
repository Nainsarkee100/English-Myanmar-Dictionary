
import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export default class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Critical App Crash:", error, errorInfo);
  }

  private handleReset = () => {
    // Basic reload
    window.location.reload();
  };

  private handleDeepReset = () => {
    if (confirm("This will clear your learning progress and saved notes. Are you sure?")) {
      localStorage.clear();
      window.location.reload();
    }
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50">
          <div className="max-w-md w-full bg-white rounded-[3rem] shadow-2xl border border-rose-100 overflow-hidden animate-in zoom-in-95 duration-500">
            <div className="bg-rose-600 p-10 text-center">
              <div className="text-7xl mb-4">😿</div>
              <h2 className="text-3xl font-black text-white">App crashed...</h2>
            </div>
            <div className="p-10 text-center">
              <p className="text-slate-500 font-medium mb-8 leading-relaxed">
                Mingalar English encountered a critical error. This can sometimes happen if your phone storage is full or corrupted.
              </p>
              
              <div className="space-y-4">
                <button
                  className="w-full bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black shadow-lg shadow-indigo-100 active:scale-95 transition-all"
                  onClick={this.handleReset}
                >
                  Reload App
                </button>
                
                <button
                  className="w-full bg-slate-50 text-slate-400 px-8 py-4 rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-rose-50 hover:text-rose-600 transition-all"
                  onClick={this.handleDeepReset}
                >
                  Reset All Data (Danger)
                </button>
              </div>

              {this.state.error && (
                <div className="mt-8 pt-8 border-t border-slate-50">
                   <p className="text-[10px] font-mono text-slate-300 break-all bg-slate-50 p-3 rounded-lg">
                     {this.state.error.message}
                   </p>
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
