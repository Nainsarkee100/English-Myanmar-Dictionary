
import React from 'react';
import { View } from '../types';

interface NavigationProps {
  currentView: View;
  setView: (view: View) => void;
  onOpenSettings?: () => void;
}

export default function Navigation({ currentView, setView, onOpenSettings }: NavigationProps) {
  const navItems: { id: View; label: string; icon: string }[] = [
    { id: 'home', label: 'Home', icon: '🏠' },
    { id: 'dictionary', label: 'Dict', icon: '📖' },
    { id: 'grammar', label: 'Grammar', icon: '✍️' },
    { id: 'quiz', label: 'Quiz', icon: '🎯' },
    { id: 'notes', label: 'Notes', icon: '📝' },
    { id: 'tutor', label: 'AI', icon: '🤖' },
  ];

  return (
    <nav className="bg-white/95 backdrop-blur-md border-b border-slate-100 sticky top-0 z-50 shadow-sm safe-top">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-1 cursor-pointer group" onClick={() => setView('home')}>
            <span className="text-2xl font-black text-indigo-600 select-none transition-transform group-active:scale-95 whitespace-nowrap">
              English For Myanmar
            </span>
          </div>
          
          <div className="hidden md:flex items-center space-x-6 h-full">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                className={`flex items-center gap-2 px-2 pt-1 text-sm font-bold transition-all border-b-[3px] h-full ${
                  currentView === item.id
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-400 hover:text-slate-600 hover:border-slate-200'
                }`}
              >
                <span>{item.icon}</span>
                {item.label}
              </button>
            ))}
            
            <div className="flex items-center gap-4 ml-4 pl-4 border-l border-slate-100">
              <button 
                onClick={onOpenSettings}
                className="p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-indigo-600 transition-all"
                aria-label="Accessibility Settings"
              >
                ♿
              </button>
              <span className="text-xl font-handwriting text-indigo-600 select-none">NSK(GU)</span>
            </div>
          </div>

          <div className="md:hidden flex items-center gap-4">
            <button 
              onClick={onOpenSettings}
              className="p-2 rounded-full bg-slate-50 text-slate-400 text-lg"
              aria-label="Accessibility Settings"
            >
              ♿
            </button>
            <div className="text-indigo-600 font-bold text-lg font-handwriting whitespace-nowrap">
              NSK(GU)
            </div>
          </div>
        </div>
      </div>
      
      <div className="md:hidden flex justify-around py-2 border-t border-slate-50 bg-white/50 overflow-x-auto no-scrollbar">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`flex flex-col items-center gap-0.5 min-w-[60px] transition-all ${
              currentView === item.id ? 'text-indigo-600' : 'text-slate-400'
            }`}
          >
            <span className={`text-xl transition-transform ${currentView === item.id ? 'scale-110' : 'scale-100'}`}>
              {item.icon}
            </span>
            <span className={`text-[10px] font-black uppercase tracking-tighter ${currentView === item.id ? 'opacity-100' : 'opacity-60'}`}>
              {item.label}
            </span>
            {currentView === item.id && <span className="w-1 h-1 bg-indigo-600 rounded-full mt-0.5"></span>}
          </button>
        ))}
      </div>
    </nav>
  );
}
