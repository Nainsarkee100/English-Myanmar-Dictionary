
import React, { useState, useEffect } from 'react';
import { getProgress, completeQuizLevel } from '../services/storage';
import { QuizLevel } from '../types';
import { QUIZ_LEVELS } from '../data/quizLevels';

interface QuizProps {
  initialLevel?: number;
}

export default function Quiz({ initialLevel }: QuizProps) {
  const [selectedLevel, setSelectedLevel] = useState<QuizLevel | null>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [completedLevels, setCompletedLevels] = useState<number[]>([]);
  const [bestScores, setBestScores] = useState<Record<number, number>>({});
  const [showExplanation, setShowExplanation] = useState(false);

  useEffect(() => {
    const progress = getProgress();
    setCompletedLevels(progress.quizLevelsCompleted || []);
    setBestScores(progress.quizScores || {});
    if (initialLevel) handleLevelSelect(initialLevel);
  }, [initialLevel]);

  const handleLevelSelect = (levelNum: number) => {
    const levelData = QUIZ_LEVELS.find(l => l.level === levelNum);
    if (levelData) {
      setSelectedLevel(levelData);
      setCurrentIdx(0);
      setScore(0);
      setShowResult(false);
      setSelectedAnswer(null);
      setShowExplanation(false);
    }
  };

  const handleAnswer = (idx: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(idx);
    setShowExplanation(true);
    if (idx === selectedLevel!.questions[currentIdx].correct) setScore(s => s + 1);
  };

  const nextQuestion = () => {
    if (currentIdx < selectedLevel!.questions.length - 1) {
      setCurrentIdx(c => c + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      setShowResult(true);
      completeQuizLevel(selectedLevel!.level, score, selectedLevel!.questions.length);
      setCompletedLevels(prev => Array.from(new Set([...prev, selectedLevel!.level])));
    }
  };

  if (!selectedLevel) {
    return (
      <div className="max-w-4xl mx-auto py-8 px-4 animate-in fade-in duration-500">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-black text-slate-900 mb-2">The Roadmap</h1>
          <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Your path to English fluency</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full">
          {Array.from({ length: 20 }, (_, i) => i + 1).map((lvl) => {
            const isCompleted = completedLevels.includes(lvl);
            const isUnlocked = lvl === 1 || completedLevels.includes(lvl - 1);
            const scorePercent = bestScores[lvl] || 0;
            
            return (
              <button
                key={lvl}
                disabled={!isUnlocked}
                onClick={() => handleLevelSelect(lvl)}
                className={`p-6 rounded-[2rem] flex items-center gap-6 transition-all border-4 ${
                  isCompleted 
                    ? 'bg-emerald-500 border-emerald-600 text-white shadow-xl' 
                    : isUnlocked
                      ? 'bg-white border-indigo-100 text-indigo-600 hover:border-indigo-600 shadow-lg'
                      : 'bg-slate-100 border-slate-200 text-slate-300 opacity-60 cursor-not-allowed'
                }`}
              >
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl shadow-inner ${
                  isCompleted ? 'bg-white/20' : isUnlocked ? 'bg-indigo-50' : 'bg-slate-50'
                }`}>
                  {lvl}
                </div>
                <div className="text-left flex-1">
                  <h3 className="font-black text-sm uppercase tracking-widest">Level {lvl}</h3>
                  <p className={`text-[10px] font-bold ${isCompleted ? 'text-emerald-100' : 'text-slate-400'}`}>
                    {isCompleted ? `Best: ${scorePercent}%` : isUnlocked ? 'Ready' : 'Locked'}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  const q = selectedLevel.questions[currentIdx];
  if (showResult) {
    const passed = score >= Math.ceil(selectedLevel.questions.length * 0.7);
    return (
      <div className="max-w-md mx-auto py-12 px-4 text-center animate-in zoom-in duration-300">
        <div className="bg-white rounded-[2.5rem] shadow-2xl p-12 border border-indigo-50">
          <span className="text-7xl block mb-6">{passed ? '🎉' : '💪'}</span>
          <h2 className="text-3xl font-black mb-2 text-slate-900">{passed ? 'Level Complete!' : 'Keep Practicing'}</h2>
          <div className="flex justify-center gap-8 my-8">
            <div><div className={`text-4xl font-black ${passed ? 'text-indigo-600' : 'text-orange-500'}`}>{score}/{selectedLevel.questions.length}</div><div className="text-[10px] font-bold text-slate-400 uppercase">Correct</div></div>
          </div>
          <button onClick={() => handleLevelSelect(selectedLevel.level)} className="w-full bg-indigo-600 text-white py-4 rounded-xl font-black shadow-lg mb-3">Retry Level</button>
          <button onClick={() => setSelectedLevel(null)} className="w-full bg-white text-slate-500 py-4 rounded-xl font-black border-2 border-slate-100">Back to Roadmap</button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8 bg-white px-6 py-4 rounded-2xl border border-slate-100 shadow-sm">
        <button onClick={() => setSelectedLevel(null)} className="text-slate-400 text-xl font-black">✕</button>
        <span className="text-sm font-black text-indigo-600 uppercase tracking-widest">Q{currentIdx + 1} / {selectedLevel.questions.length}</span>
        <div className="w-1/3 bg-slate-100 h-2 rounded-full overflow-hidden">
          <div className="bg-indigo-500 h-full transition-all duration-300" style={{ width: `${((currentIdx + 1) / selectedLevel.questions.length) * 100}%` }} />
        </div>
      </div>
      <div className="bg-white rounded-[2.5rem] shadow-xl border border-slate-50 p-10 mb-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-10 leading-snug">{q.question}</h2>
        <div className="grid grid-cols-1 gap-4">
          {q.options.map((opt, i) => (
            <button key={i} disabled={selectedAnswer !== null} onClick={() => handleAnswer(i)}
              className={`p-6 rounded-2xl border-2 text-left font-bold transition-all ${
                selectedAnswer === null ? 'border-slate-100 hover:border-indigo-300' : 
                i === q.correct ? 'border-emerald-500 bg-emerald-50 text-emerald-700' :
                selectedAnswer === i ? 'border-rose-500 bg-rose-50 text-rose-700' : 'opacity-40'
              }`}>
              {opt}
            </button>
          ))}
        </div>
      </div>
      {showExplanation && (
        <div className="bg-indigo-50 rounded-3xl p-6 border border-indigo-100 animate-in slide-in-from-top-4">
          <p className="text-indigo-800 font-medium mb-6 leading-relaxed">💡 {q.explanation}</p>
          <button onClick={nextQuestion} className="w-full bg-indigo-600 text-white py-4 rounded-xl font-black shadow-lg">
            {currentIdx === selectedLevel.questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
          </button>
        </div>
      )}
    </div>
  );
}
