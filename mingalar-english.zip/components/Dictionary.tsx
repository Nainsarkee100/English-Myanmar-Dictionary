
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { dictionaryLookup } from '../services/geminiService';
import { getDictionaryFromCache, saveToDictionaryCache, getPrefixSuggestions, getAllOfflineWords } from '../services/storage';
import { DictionaryResult } from '../types';

export default function Dictionary() {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DictionaryResult | null>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [error, setError] = useState('');
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isBrowseMode, setIsBrowseMode] = useState(false);
  
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<number | null>(null);

  useEffect(() => {
    const update = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, []);

  const offlineWords = useMemo(() => isBrowseMode ? getAllOfflineWords() : [], [isBrowseMode]);

  useEffect(() => {
    const trimmed = query.trim().toLowerCase();
    
    if (!trimmed) {
      setResult(null);
      setSuggestions([]);
      return;
    }

    const local = getDictionaryFromCache(trimmed);
    if (local) {
      setResult(local);
      setError('');
    } else {
      setResult(null);
    }

    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    
    debounceRef.current = window.setTimeout(() => {
      if (trimmed.length > 0 && !local) {
        const matches = getPrefixSuggestions(trimmed, 8);
        setSuggestions(matches);
      } else {
        setSuggestions([]);
      }
    }, 300);

    return () => {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
    };
  }, [query]);

  const performSearch = useCallback(async (wordToSearch: string) => {
    const word = wordToSearch.trim().toLowerCase();
    if (!word) return;
    
    setLoading(true);
    setError('');
    setSuggestions([]);
    setIsBrowseMode(false);
    
    const local = getDictionaryFromCache(word);
    if (local) {
      setResult(local);
      setLoading(false);
      return;
    }

    if (!isOnline) {
      setError('This word is not in your offline database. Connect to search online.');
      setLoading(false);
      return;
    }

    try {
      const data = await dictionaryLookup(word);
      saveToDictionaryCache(data);
      setResult({ ...data, isOffline: true });
    } catch (err: any) {
      const msg = err.message === "TIMEOUT_ERROR" 
        ? "Network connection timed out. Please check your signal." 
        : "Definition not found. Try another word.";
      setError(msg);
      
      // Also report as a warning if it's a timeout
      if (err.message === "TIMEOUT_ERROR") {
        window.dispatchEvent(new CustomEvent('appMessage', { 
          detail: { message: "Slow connection detected.", type: "warning" } 
        }));
      }
    } finally {
      setLoading(false);
    }
  }, [isOnline]);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(query);
  };

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-US';
      u.rate = 0.9;
      window.speechSynthesis.speak(u);
    }
  };

  const getPosColor = (pos?: string) => {
    switch(pos) {
      case 'noun': return 'bg-blue-100 text-blue-700';
      case 'verb': return 'bg-red-100 text-red-700';
      case 'adj': return 'bg-emerald-100 text-emerald-700';
      case 'adv': return 'bg-purple-100 text-purple-700';
      case 'pronoun': return 'bg-amber-100 text-amber-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-8 px-4 pb-24 animate-in fade-in duration-500">
      <header className="mb-8 flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-black text-slate-900 mb-2">Dictionary</h1>
          <p className="text-slate-400 font-bold text-sm">Instant Myanmar translations.</p>
        </div>
        <button 
          onClick={() => setIsBrowseMode(!isBrowseMode)}
          className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
            isBrowseMode ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-100 text-slate-500'
          }`}
        >
          {isBrowseMode ? 'Close Library' : 'Browse All'}
        </button>
      </header>

      <div className="relative mb-10 group">
        <form onSubmit={handleFormSubmit} className="relative z-20">
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type an English word..."
            className="w-full pl-8 pr-28 py-6 rounded-[2rem] border-2 border-slate-100 focus:border-indigo-500 bg-white shadow-2xl outline-none transition-all text-xl font-bold placeholder:text-slate-300"
          />
          <button
            type="submit"
            disabled={loading || !query.trim()}
            className="absolute right-3 top-3 bottom-3 px-8 bg-slate-900 text-white rounded-2xl font-black active:scale-95 transition-all shadow-xl disabled:bg-slate-100 disabled:text-slate-300"
          >
            {loading ? (
              <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : 'Go'}
          </button>
        </form>

        {suggestions.length > 0 && !result && (
          <div className="absolute top-full left-0 right-0 mt-3 bg-white rounded-[2rem] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.2)] border border-slate-100 overflow-hidden z-30 animate-in slide-in-from-top-2 duration-200">
            {suggestions.map(s => (
              <button
                key={s}
                onClick={() => { setQuery(s); performSearch(s); }}
                className="w-full px-8 py-5 text-left hover:bg-indigo-50 flex justify-between items-center group/item transition-colors border-b border-slate-50 last:border-0"
              >
                <span className="font-bold text-slate-700 capitalize text-lg">{s}</span>
                <span className="text-[9px] font-black text-slate-300 group-hover/item:text-indigo-400 tracking-widest uppercase">Saved ⚡</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {isBrowseMode && !result && (
        <div className="bg-white rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden mb-12 animate-in zoom-in-95">
          <div className="p-6 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
            <h3 className="font-black text-slate-800 text-sm uppercase tracking-widest">Offline Library</h3>
            <span className="text-[10px] font-black text-slate-400">{offlineWords.length} Words Available</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-6 max-h-[400px] overflow-y-auto no-scrollbar">
            {offlineWords.map(word => (
              <button
                key={word}
                onClick={() => { setQuery(word); performSearch(word); }}
                className="px-4 py-3 rounded-xl bg-slate-50 hover:bg-indigo-50 border border-slate-100 hover:border-indigo-200 transition-all text-left font-bold text-slate-700 capitalize text-sm"
              >
                {word}
              </button>
            ))}
          </div>
        </div>
      )}

      {error && (
        <div className="bg-rose-50 text-rose-800 p-6 rounded-3xl mb-8 text-sm font-bold border border-rose-100 flex items-center gap-4 animate-shake">
          <span className="text-xl">⚠️</span> {error}
        </div>
      )}

      {result ? (
        <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-50 overflow-hidden animate-in zoom-in-95 duration-500 will-change-transform">
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-10 text-white relative">
            <div className="flex justify-between items-start">
              <div className="flex-1 pr-4">
                <div className="flex items-center gap-3 mb-2 flex-wrap">
                  <h2 className="text-5xl font-black capitalize break-all">{result.word}</h2>
                  {result.partOfSpeech && (
                    <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest ${getPosColor(result.partOfSpeech)}`}>
                      {result.partOfSpeech}
                    </span>
                  )}
                </div>
                <p className="text-indigo-100 font-mono tracking-widest text-lg">{result.phonetic}</p>
              </div>
              <button 
                onClick={() => speak(result.word)} 
                className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center hover:bg-white/30 active:scale-90 transition-all text-2xl shadow-xl flex-shrink-0"
              >
                🔊
              </button>
            </div>
            <div className="mt-6 flex items-center gap-2">
               <span className="bg-white/20 px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest">Offline Ready</span>
            </div>
          </div>
          
          <div className="p-10 space-y-10">
            <section>
              <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-3">Myanmar Translation</h4>
              <p className="text-3xl font-black text-slate-800 font-padauk leading-tight">{result.myanmarMeaning}</p>
            </section>

            <section className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100">
              <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-2">Definition</h4>
              <p className="text-slate-600 font-bold leading-relaxed text-lg">{result.definition}</p>
            </section>

            {result.examples?.length > 0 && (
              <section>
                <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-6">Sentence Usage</h4>
                <div className="space-y-4">
                  {result.examples.map((ex, i) => (
                    <div key={i} className="flex gap-4 items-start group">
                      <div className="w-2 h-2 rounded-full bg-indigo-200 mt-2.5 group-hover:bg-indigo-500 transition-colors"></div>
                      <p className="text-slate-700 font-bold italic text-lg leading-relaxed">"{ex}"</p>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>
      ) : (
        !query && !isBrowseMode && (
          <div className="text-center py-24 opacity-30 select-none pointer-events-none">
            <div className="text-8xl mb-6">🔍</div>
            <p className="font-black text-slate-400 text-xl">Pre-indexed search active.<br/>Find 5000+ words in milliseconds.</p>
          </div>
        )
      )}
    </div>
  );
}
