
import React, { useState, useEffect, useMemo } from 'react';
import { getGrammarMetadata, getGrammarLessonById, updatePointProgress, getProgress, markGrammarAsCompleted } from '../services/storage';
import { GrammarLesson } from '../types';

interface GrammarProps {
  onNavigateToQuiz?: (level: number) => void;
}

export default function Grammar({ onNavigateToQuiz }: GrammarProps) {
  const [selectedLessonId, setSelectedLessonId] = useState<string | null>(null);
  const [activeLesson, setActiveLesson] = useState<GrammarLesson | null>(null);
  const [activeTab, setActiveTab] = useState<'lesson' | 'examples' | 'practice'>('lesson');
  const [practiceAnswers, setPracticeAnswers] = useState<Record<string, number>>({});
  const [filter, setFilter] = useState<'All' | 'Primary' | 'Middle' | 'High'>('All');
  const [completedIds, setCompletedIds] = useState<string[]>([]);

  const filteredMetadata = useMemo(() => getGrammarMetadata(filter), [filter]);

  useEffect(() => {
    setCompletedIds(getProgress().grammarCompleted);
  }, []);

  useEffect(() => {
    if (selectedLessonId) {
      setActiveLesson(getGrammarLessonById(selectedLessonId));
      setPracticeAnswers({});
      setActiveTab('lesson');
    } else setActiveLesson(null);
  }, [selectedLessonId]);

  const handleAnswer = (questionId: string, optionIndex: number, correctIndex: number) => {
    if (practiceAnswers[questionId] !== undefined) return;
    setPracticeAnswers(prev => {
      const updated = { ...prev, [questionId]: optionIndex };
      if (activeLesson && Object.keys(updated).length === activeLesson.practice.length) {
        markGrammarAsCompleted(activeLesson.id, activeLesson.title);
        setCompletedIds(prev => Array.from(new Set([...prev, activeLesson.id])));
      }
      return updated;
    });
    if (optionIndex === correctIndex) updatePointProgress(5);
  };

  const goToNextLesson = () => {
    const currentIndex = filteredMetadata.findIndex(m => m.id === selectedLessonId);
    if (currentIndex < filteredMetadata.length - 1) {
      setSelectedLessonId(filteredMetadata[currentIndex + 1].id);
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 pb-24">
      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:w-80 flex-shrink-0">
          <h2 className="text-3xl font-black text-slate-900 mb-2">Grammar</h2>
          <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar pb-2">
            {['All', 'Primary', 'Middle', 'High'].map(lvl => (
              <button key={lvl} onClick={() => setFilter(lvl as any)}
                className={`px-4 py-2 rounded-xl text-[10px] font-black border-2 ${filter === lvl ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-slate-100 text-slate-400'}`}>
                {lvl}
              </button>
            ))}
          </div>
          <div className="space-y-3 lg:h-[calc(100vh-20rem)] overflow-y-auto pr-2 pb-10 no-scrollbar">
            {filteredMetadata.map((topic) => (
              <button key={topic.id} onClick={() => setSelectedLessonId(topic.id)}
                className={`w-full text-left p-5 rounded-[1.5rem] border-2 transition-all ${selectedLessonId === topic.id ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'bg-white border-slate-100 hover:border-indigo-100'}`}>
                <div className="flex justify-between items-start mb-2">
                  <span className="font-black text-sm">{topic.title}</span>
                  {completedIds.includes(topic.id) && <span className="text-xs">✅</span>}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1">
          {!activeLesson ? (
            <div className="bg-white rounded-[3rem] p-16 text-center border-2 border-dashed border-slate-200 h-full flex flex-col items-center justify-center">
              <div className="text-8xl mb-8">📖</div>
              <h3 className="text-3xl font-black text-slate-800">Choose a Lesson</h3>
              <p className="text-slate-400 font-bold mt-2">Start your grammar journey here.</p>
            </div>
          ) : (
            <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-50 overflow-hidden">
              <div className="flex bg-slate-50 p-3 gap-3 border-b border-slate-100">
                {['lesson', 'examples', 'practice'].map(tab => (
                  <button key={tab} onClick={() => setActiveTab(tab as any)}
                    className={`flex-1 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-white text-indigo-600 shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}>
                    {tab}
                  </button>
                ))}
              </div>
              <div className="p-8 lg:p-14 min-h-[600px]">
                {activeTab === 'lesson' && (
                  <div className="animate-in fade-in slide-in-from-bottom-4">
                    <h1 className="text-4xl font-black mb-8">{activeLesson.title}</h1>
                    <div className="bg-indigo-50/30 p-8 rounded-[2rem] border-l-8 border-indigo-500 mb-8"><p className="text-lg font-bold">{activeLesson.summary}</p></div>
                    <p className="text-xl font-bold text-slate-700 mb-8 leading-relaxed">{activeLesson.explanation}</p>
                    <div className="bg-indigo-50/50 p-10 rounded-[2.5rem] border-2 border-indigo-100"><p className="text-xl font-bold font-padauk leading-loose">{activeLesson.myanmarExplanation}</p></div>
                  </div>
                )}
                {activeTab === 'examples' && (
                  <div className="grid gap-6 animate-in fade-in slide-in-from-bottom-4">
                    {activeLesson.examples.map((ex, i) => (
                      <div key={i} className="p-10 rounded-[2.5rem] border-2 border-slate-50 bg-white shadow-sm">
                        <p className="text-3xl font-black mb-4">{ex.english}</p>
                        <p className="text-xl text-slate-400 font-padauk">{ex.myanmar}</p>
                      </div>
                    ))}
                  </div>
                )}
                {activeTab === 'practice' && (
                  <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4">
                    {activeLesson.practice.map((q, idx) => (
                      <div key={q.id} className="space-y-6">
                        <h3 className="text-2xl font-bold">{idx + 1}. {q.question}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {q.options.map((opt, optIdx) => (
                            <button key={optIdx} disabled={practiceAnswers[q.id] !== undefined} onClick={() => handleAnswer(q.id, optIdx, q.correctIndex)}
                              className={`p-6 rounded-3xl border-2 font-black text-lg transition-all ${
                                practiceAnswers[q.id] === undefined ? 'bg-white border-slate-100 hover:border-indigo-300' : 
                                optIdx === q.correctIndex ? 'bg-emerald-500 text-white border-emerald-600' : 
                                practiceAnswers[q.id] === optIdx ? 'bg-rose-500 text-white border-rose-600' : 'opacity-40'
                              }`}>
                              {opt}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                    {Object.keys(practiceAnswers).length === activeLesson.practice.length && (
                      <div className="p-10 bg-emerald-500 rounded-[3rem] text-white text-center shadow-2xl">
                        <h3 className="text-3xl font-black mb-4">Lesson Complete! 🎉</h3>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                          {activeLesson.relatedQuizLevel && (
                            <button onClick={() => onNavigateToQuiz?.(activeLesson.relatedQuizLevel!)} className="bg-white text-emerald-600 px-8 py-4 rounded-xl font-black shadow-lg">Go to Quiz {activeLesson.relatedQuizLevel}</button>
                          )}
                          <button onClick={goToNextLesson} className="bg-emerald-700 text-white px-8 py-4 rounded-xl font-black shadow-lg">Next Lesson →</button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
