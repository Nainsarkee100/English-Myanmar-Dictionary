
import React, { useEffect, useState, useMemo } from 'react';
import { View, UserProgress, ActivityEntry } from '../types';
import { getProgress, getTotalGrammarCount, getGrammarMetadata } from '../services/storage';

interface HomeProps {
  setView: (view: View, params?: any) => void;
}

export default function Home({ setView }: HomeProps) {
  const [progress, setProgress] = useState<UserProgress | null>(null);
  const totalGrammar = getTotalGrammarCount();

  useEffect(() => {
    setProgress(getProgress());
  }, []);

  const nextMission = useMemo(() => {
    if (!progress) return null;
    const grammarMetadata = getGrammarMetadata('All');
    const nextLesson = grammarMetadata.find(m => !progress.grammarCompleted.includes(m.id));
    if (nextLesson) return { type: 'grammar', id: nextLesson.id, title: nextLesson.title, label: 'Study Next Topic', icon: '📖' };
    const lastQuiz = Math.max(0, ...progress.quizLevelsCompleted);
    if (lastQuiz < 20) return { type: 'quiz', level: lastQuiz + 1, title: `Level ${lastQuiz + 1}`, label: 'Unlock Next Quiz', icon: '🎯' };
    return null;
  }, [progress]);

  const stats = useMemo(() => {
    if (!progress) return { grammar: 0, quiz: 0, words: 0 };
    return {
      grammar: Math.round((progress.grammarCompleted.length / totalGrammar) * 100),
      quiz: Math.round((progress.quizLevelsCompleted.length / 20) * 100),
      words: Math.min(100, Math.round((progress.wordsLearned / 500) * 100))
    };
  }, [progress, totalGrammar]);

  const getTimeAgo = (isoDate: string) => {
    const diff = Date.now() - new Date(isoDate).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return new Date(isoDate).toLocaleDateString();
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 animate-in fade-in slide-in-from-bottom-2 duration-500">
      {/* Central Hero Header */}
      <header className="mb-16 pt-10 flex flex-col items-center text-center">
        <h1 className="text-6xl md:text-7xl font-black text-slate-900 mb-6 leading-tight tracking-tight">
          Mingalar Par!
        </h1>
        
        <p className="text-slate-500 font-medium text-lg max-w-lg mb-8">
          Welcome back to your English journey. Ready to level up your skills today?
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <div className="flex items-center gap-2 bg-white px-5 py-2.5 rounded-2xl border border-slate-100 shadow-sm">
            <span className="flex h-2.5 w-2.5 rounded-full bg-green-500 animate-pulse"></span>
            <p className="text-slate-500 font-black text-[10px] uppercase tracking-widest">Intermediate Learner</p>
          </div>
          
          <div className="flex gap-3">
            <div className="bg-white px-5 py-2.5 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-2 group hover:border-orange-200 transition-colors">
              <span className="text-lg font-black text-orange-500 group-hover:scale-110 transition-transform">🔥 {progress?.streak || 0}</span>
              <span className="text-[10px] font-black text-slate-300 uppercase tracking-tighter">Day Streak</span>
            </div>
            <div className="bg-slate-900 px-5 py-2.5 rounded-2xl text-white flex items-center gap-2 shadow-xl hover:bg-indigo-600 transition-colors">
              <span className="text-lg font-black text-white">⭐ {progress?.totalPoints || 0}</span>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">Total XP</span>
            </div>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        {/* Left Col: Next Mission & Skills */}
        <div className="lg:col-span-2 space-y-8">
          {nextMission && (
            <div className="bg-indigo-600 rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden group border-4 border-white">
              <div className="relative z-10">
                <h3 className="text-[10px] font-black uppercase tracking-widest mb-4 opacity-70">Recommended Activity</h3>
                <h2 className="text-4xl font-black mb-2">{nextMission.title}</h2>
                <p className="text-indigo-100 font-bold mb-10 text-lg">{nextMission.label}</p>
                <button 
                  onClick={() => setView(nextMission.type as any, nextMission.type === 'quiz' ? { quizLevel: nextMission.level } : {})}
                  className="bg-white text-indigo-600 px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl active:scale-95 hover:bg-indigo-50 transition-all"
                >
                  Start Now {nextMission.icon}
                </button>
              </div>
              <div className="absolute -bottom-10 -right-10 text-[14rem] opacity-10 pointer-events-none group-hover:rotate-12 transition-transform duration-1000">
                {nextMission.icon}
              </div>
            </div>
          )}

          <div className="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-xl">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-10">Skill Proficiency</h3>
            <div className="space-y-8">
              {[
                { label: 'Grammar Mastery', val: stats.grammar, color: 'bg-indigo-500' },
                { label: 'Quiz Accuracy', val: stats.quiz, color: 'bg-orange-500' },
                { label: 'Active Vocabulary', val: stats.words, color: 'bg-emerald-500' },
              ].map(skill => (
                <div key={skill.label}>
                  <div className="flex justify-between items-end mb-3">
                    <span className="text-base font-black text-slate-700">{skill.label}</span>
                    <span className="text-sm font-black text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-lg">{skill.val}%</span>
                  </div>
                  <div className="w-full bg-slate-50 h-4 rounded-full overflow-hidden p-1 border border-slate-100">
                    <div className={`${skill.color} h-full rounded-full transition-all duration-1000 shadow-inner`} style={{ width: `${skill.val}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Activity Log */}
        <div className="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-xl h-fit">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest">
              Recent Logs
            </h3>
            <span className="text-[10px] font-black text-indigo-600 cursor-pointer hover:underline">Clear History</span>
          </div>
          <div className="space-y-7">
            {progress?.history && progress.history.length > 0 ? (
              progress.history.map((item, i) => (
                <div key={i} className="flex gap-4 group cursor-default">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-sm transition-transform group-hover:scale-110 ${
                    item.type === 'grammar' ? 'bg-indigo-50 text-indigo-600' :
                    item.type === 'quiz' ? 'bg-orange-50 text-orange-600' : 'bg-emerald-50 text-emerald-600'
                  }`}>
                    {item.type === 'grammar' ? '📖' : item.type === 'quiz' ? '🎯' : '🔤'}
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-sm font-black text-slate-800 truncate leading-none mb-1.5 group-hover:text-indigo-600 transition-colors">
                      {item.label}
                    </p>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-slate-300 uppercase tracking-tight">{getTimeAgo(item.timestamp)}</span>
                      {item.score !== undefined && (
                        <span className="text-[10px] font-black text-emerald-500 bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-100">Result: {item.score}%</span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <div className="text-4xl mb-4 grayscale opacity-50">📋</div>
                <p className="text-xs font-bold text-slate-300">No activity yet. Start your first lesson!</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Persistence Info */}
      <div className="text-center py-10">
        <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-100 rounded-full text-[10px] font-black text-slate-400 uppercase tracking-widest">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          All data stored locally — Version {progress?.version || 0}.0
        </div>
      </div>
    </div>
  );
}
