import React from 'react';
import { AccessibilitySettings, FontSize } from '../types';

interface Props {
  settings: AccessibilitySettings;
  onUpdate: (settings: AccessibilitySettings) => void;
  onClose: () => void;
}

const fontSizes: { value: FontSize; label: string }[] = [
  { value: 'small', label: 'A-' },
  { value: 'medium', label: 'A' },
  { value: 'large', label: 'A+' },
  { value: 'extra-large', label: 'A++' },
];

export default function AccessibilityControls({ settings, onUpdate, onClose }: Props) {
  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div 
        className="w-full max-w-sm bg-white rounded-[2.5rem] shadow-2xl overflow-hidden border border-slate-100 animate-in slide-in-from-bottom-10 sm:slide-in-from-bottom-0 duration-500"
        role="dialog"
        aria-modal="true"
        aria-labelledby="accessibility-title"
      >
        <div className="p-8">
          <div className="flex justify-between items-center mb-8">
            <h2 id="accessibility-title" className="text-2xl font-black text-slate-900">Accessibility</h2>
            <button 
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold active:scale-95 transition-all"
              aria-label="Close settings"
            >
              ✕
            </button>
          </div>

          <div className="space-y-8">
            {/* Font Size Scaling */}
            <section>
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Reading Size</h3>
              <div className="grid grid-cols-4 gap-2">
                {fontSizes.map((fs) => (
                  <button
                    key={fs.value}
                    onClick={() => onUpdate({ ...settings, fontSize: fs.value })}
                    className={`py-4 rounded-2xl font-black transition-all border-2 ${
                      settings.fontSize === fs.value
                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg'
                        : 'bg-white border-slate-100 text-slate-400 hover:border-indigo-100'
                    }`}
                    aria-label={`Set font size to ${fs.label}`}
                    aria-pressed={settings.fontSize === fs.value}
                  >
                    {fs.label}
                  </button>
                ))}
              </div>
            </section>

            {/* High Contrast Toggle */}
            <section>
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Display Contrast</h3>
              <button
                onClick={() => onUpdate({ ...settings, highContrast: !settings.highContrast })}
                className={`w-full p-6 rounded-[2rem] border-2 flex items-center justify-between transition-all ${
                  settings.highContrast
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg'
                    : 'bg-white border-slate-100 text-slate-700 hover:border-indigo-100'
                }`}
                aria-pressed={settings.highContrast}
              >
                <div className="text-left">
                  <p className="font-black text-sm">High Contrast Mode</p>
                  <p className={`text-[10px] font-bold ${settings.highContrast ? 'text-indigo-100' : 'text-slate-400'}`}>
                    Easier to see for low-vision users
                  </p>
                </div>
                <div className={`w-12 h-6 rounded-full relative transition-colors ${settings.highContrast ? 'bg-indigo-400' : 'bg-slate-200'}`}>
                  <div className={`absolute top-1 bottom-1 w-4 h-4 rounded-full bg-white transition-all ${settings.highContrast ? 'right-1' : 'left-1'}`}></div>
                </div>
              </button>
            </section>

            <section className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
              <p className="text-[10px] font-bold text-slate-400 leading-relaxed">
                Tip: We use <span className="text-slate-900">Inter</span> and <span className="text-slate-900">Padauk</span> fonts for maximum legibility in English and Myanmar scripts.
              </p>
            </section>
          </div>

          <button 
            onClick={onClose}
            className="w-full mt-10 bg-slate-900 text-white py-5 rounded-[2rem] font-black shadow-xl active:scale-95 transition-all"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
