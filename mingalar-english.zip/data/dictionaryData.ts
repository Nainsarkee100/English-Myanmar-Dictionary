
import { DictionaryResult } from "../types";

export const PRESEEDED_WORDS: Record<string, DictionaryResult> = {
  // --- A ---
  "abandon": {
    word: "Abandon",
    partOfSpeech: "verb",
    phonetic: "/əˈbæn.dən/",
    myanmarMeaning: "စွန့်ပစ်သည်",
    definition: "To leave a place, thing, or person forever.",
    examples: ["They had to abandon their car in the flood.", "Do not abandon your dreams."],
    synonyms: ["Leave", "Desert"]
  },
  "ability": {
    word: "Ability",
    partOfSpeech: "noun",
    phonetic: "/əˈbɪl.ə.ti/",
    myanmarMeaning: "စွမ်းရည် / တတ်နိုင်စွမ်း",
    definition: "The physical or mental power or skill needed to do something.",
    examples: ["She has the ability to speak three languages.", "Hard work improves your ability."],
    synonyms: ["Skill", "Capability"]
  },
  "accurate": {
    word: "Accurate",
    partOfSpeech: "adj",
    phonetic: "/ˈæk.jə.rət/",
    myanmarMeaning: "တိကျသော / မှန်ကန်သော",
    definition: "Correct, exact, and without any mistakes.",
    examples: ["The clock is very accurate.", "Is the translation accurate?"],
    synonyms: ["Precise", "Correct"]
  },
  "achieve": {
    word: "Achieve",
    partOfSpeech: "verb",
    phonetic: "/əˈtʃiːv/",
    myanmarMeaning: "အောင်မြင်အောင်လုပ်ဆောင်သည် / ရရှိသည်",
    definition: "To succeed in finishing something or reaching an aim.",
    examples: ["You can achieve your goals if you study hard.", "He achieved high marks in his Grade 12 exam."],
    synonyms: ["Attain", "Reach"]
  },
  "admire": {
    word: "Admire",
    partOfSpeech: "verb",
    phonetic: "/ədˈmaɪər/",
    myanmarMeaning: "လေးစားအားကျသည်",
    definition: "To find someone or something attractive and pleasant to look at.",
    examples: ["I admire my teacher for her patience.", "Many people admire the beauty of Bagan."],
    synonyms: ["Respect", "Appreciate"]
  },
  "advantage": {
    word: "Advantage",
    partOfSpeech: "noun",
    phonetic: "/ədˈvɑːn.tɪdʒ/",
    myanmarMeaning: "သာလွန်ကောင်းမွန်သောအချက် / အကျိုးကျေးဇူး",
    definition: "A condition or circumstance that puts one in a favorable or superior position.",
    examples: ["Learning English is a big advantage for your career.", "The advantage of living in a city is good transportation."],
    synonyms: ["Benefit", "Profit"]
  },
  "ancient": {
    word: "Ancient",
    partOfSpeech: "adj",
    phonetic: "/ˈeɪn.ʃənt/",
    myanmarMeaning: "ရှေးဟောင်းသော / ရှေးကျသော",
    definition: "Of or from a long time ago, having lasted for a very long time.",
    examples: ["Bagan is an ancient city in Myanmar.", "Ancient history is very interesting."],
    synonyms: ["Antique", "Old"]
  },

  // --- B ---
  "background": {
    word: "Background",
    partOfSpeech: "noun",
    phonetic: "/ˈbæk.ɡraʊnd/",
    myanmarMeaning: "နောက်ခံအကြောင်းအရာ",
    definition: "The things that can be seen behind the main things or people in a picture.",
    examples: ["Can you tell me about your educational background?", "The photo has a blue background."],
    synonyms: ["Setting", "History"]
  },
  "benefit": {
    word: "Benefit",
    partOfSpeech: "noun",
    phonetic: "/ˈben.ɪ.fɪt/",
    myanmarMeaning: "အကျိုးကျေးဇူး",
    definition: "A helpful or good effect, or something intended to help.",
    examples: ["The new hospital will benefit the local people.", "Exercise has many benefits for health."],
    synonyms: ["Advantage", "Gain"]
  },
  "brave": {
    word: "Brave",
    partOfSpeech: "adj",
    phonetic: "/breɪv/",
    myanmarMeaning: "သတ္တိရှိသော",
    definition: "Showing no fear of dangerous or difficult things.",
    examples: ["He was a brave soldier.", "You need to be brave to speak English with foreigners."],
    synonyms: ["Courageous", "Fearless"]
  },
  "brief": {
    word: "Brief",
    partOfSpeech: "adj",
    phonetic: "/briːf/",
    myanmarMeaning: "တိုတောင်းသော / ကျဉ်းငုတ်သော",
    definition: "Lasting only a short time or using only a few words.",
    examples: ["The meeting was very brief.", "Give me a brief explanation."],
    synonyms: ["Short", "Concise"]
  },

  // --- C ---
  "candidate": {
    word: "Candidate",
    partOfSpeech: "noun",
    phonetic: "/ˈkæn.dɪ.dət/",
    myanmarMeaning: "လောင်းလျာ / ဖြေဆိုသူ",
    definition: "A person who is competing to get a job or elected position.",
    examples: ["There are many candidates for the exam.", "She is a candidate for the job."],
    synonyms: ["Applicant", "Contender"]
  },
  "century": {
    word: "Century",
    partOfSpeech: "noun",
    phonetic: "/ˈsen.tʃər.i/",
    myanmarMeaning: "ရာစုနှစ် (နှစ် ၁၀၀)",
    definition: "A period of 100 years.",
    examples: ["We are living in the 21st century.", "The building was built a century ago."],
    synonyms: []
  },
  "challenge": {
    word: "Challenge",
    partOfSpeech: "noun",
    phonetic: "/ˈtʃæl.ɪndʒ/",
    myanmarMeaning: "စိန်ခေါ်မှု",
    definition: "Something that needs great mental or physical effort in order to be done successfully.",
    examples: ["Learning English grammar is a big challenge.", "I like to take on new challenges."],
    synonyms: ["Test", "Problem"]
  },
  "citizen": {
    word: "Citizen",
    partOfSpeech: "noun",
    phonetic: "/ˈsɪt.ɪ.zən/",
    myanmarMeaning: "နိုင်ငံသား",
    definition: "A person who is a member of a particular country.",
    examples: ["I am a citizen of Myanmar.", "Good citizens follow the law."],
    synonyms: ["Resident", "National"]
  },
  "climate": {
    word: "Climate",
    partOfSpeech: "noun",
    phonetic: "/ˈklaɪ.mət/",
    myanmarMeaning: "ရာသီဥတု (ရေရှည်)",
    definition: "The general weather conditions usually found in a particular place.",
    examples: ["Myanmar has a tropical climate.", "Climate change is a global problem."],
    synonyms: ["Weather"]
  },

  // --- D ---
  "debate": {
    word: "Debate",
    partOfSpeech: "noun",
    phonetic: "/dɪˈbeɪt/",
    myanmarMeaning: "အချေအတင်ဆွေးနွေးခြင်း / စကားစစ်ထိုးပွဲ",
    definition: "A serious discussion of a subject in which many people take part.",
    examples: ["The students had a debate about technology.", "There is a lot of debate about this topic."],
    synonyms: ["Discussion", "Argument"]
  },
  "decision": {
    word: "Decision",
    partOfSpeech: "noun",
    phonetic: "/dɪˈsɪʒ.ən/",
    myanmarMeaning: "ဆုံးဖြတ်ချက်",
    definition: "A choice that you make about something after thinking about several possibilities.",
    examples: ["Making a decision is difficult.", "Have you made a decision yet?"],
    synonyms: ["Choice", "Judgment"]
  },
  "delicious": {
    word: "Delicious",
    partOfSpeech: "adj",
    phonetic: "/dɪˈlɪʃ.əs/",
    myanmarMeaning: "အရသာရှိသော",
    definition: "Having a very pleasant taste or smell.",
    examples: ["Mohinga is a delicious Myanmar breakfast.", "The food at the market is delicious."],
    synonyms: ["Tasty", "Yummy"]
  },
  "depend": {
    word: "Depend",
    partOfSpeech: "verb",
    phonetic: "/dɪˈpend/",
    myanmarMeaning: "မှီခိုသည် / မူတည်သည်",
    definition: "To be decided by or to change according to something else.",
    examples: ["Our trip depends on the weather.", "I depend on my parents for support."],
    synonyms: ["Rely", "Hinge"]
  },

  // --- E ---
  "education": {
    word: "Education",
    partOfSpeech: "noun",
    phonetic: "/ˌedʒ.ʊˈkeɪ.ʃən/",
    myanmarMeaning: "ပညာရေး",
    definition: "The process of teaching or learning, especially in a school or college.",
    examples: ["Education is the key to success.", "Every child deserves a good education."],
    synonyms: ["Schooling", "Learning"]
  },
  "effective": {
    word: "Effective",
    partOfSpeech: "adj",
    phonetic: "/ɪˈfek.tɪv/",
    myanmarMeaning: "ထိရောက်သော",
    definition: "Successful or achieving the results that you want.",
    examples: ["This medicine is very effective.", "Find an effective way to study."],
    synonyms: ["Efficient", "Potent"]
  },
  "encourage": {
    word: "Encourage",
    partOfSpeech: "verb",
    phonetic: "/ɪnˈkʌr.ɪdʒ/",
    myanmarMeaning: "အားပေးတိုက်တွန်းသည်",
    definition: "To help someone to feel confident and able to do something.",
    examples: ["My parents encourage me to study English.", "The teacher encouraged the students to ask questions."],
    synonyms: ["Support", "Inspire"]
  },
  "environment": {
    word: "Environment",
    partOfSpeech: "noun",
    phonetic: "/ɪnˈvaɪ.rən.mənt/",
    myanmarMeaning: "ပတ်ဝန်းကျင်",
    definition: "The air, water, and land in or on which people, animals, and plants live.",
    examples: ["We must protect our environment.", "Pollution is bad for the environment."],
    synonyms: ["Surroundings", "Nature"]
  },

  // --- F ---
  "famous": {
    word: "Famous",
    partOfSpeech: "adj",
    phonetic: "/ˈfeɪ.məs/",
    myanmarMeaning: "ကျော်ကြားသော",
    definition: "Known and recognized by many people.",
    examples: ["The Shwedagon Pagoda is famous around the world.", "He is a famous singer."],
    synonyms: ["Well-known", "Celebrated"]
  },
  "flexible": {
    word: "Flexible",
    partOfSpeech: "adj",
    phonetic: "/ˈflek.sə.bəl/",
    myanmarMeaning: "ပြောင်းလွယ်ပြင်လွယ်ရှိသော",
    definition: "Able to change or be changed easily according to the situation.",
    examples: ["My working hours are flexible.", "A flexible person can adapt to new situations."],
    synonyms: ["Adaptable", "Pliable"]
  },
  "foreign": {
    word: "Foreign",
    partOfSpeech: "adj",
    phonetic: "/ˈfɒr.ən/",
    myanmarMeaning: "နိုင်ငံခြားမှ / သူစိမ်းဖြစ်သော",
    definition: "Belonging or connected to a country which is not your own.",
    examples: ["I like to learn foreign languages.", "She has visited many foreign countries."],
    synonyms: ["Overseas", "External"]
  },

  // --- G ---
  "generation": {
    word: "Generation",
    partOfSpeech: "noun",
    phonetic: "/ˌdʒen.əˈreɪ.ʃən/",
    myanmarMeaning: "မျိုးဆက်",
    definition: "All the people of about the same age within a society or within a family.",
    examples: ["The younger generation is good at technology.", "My grandparents belong to a different generation."],
    synonyms: []
  },
  "global": {
    word: "Global",
    partOfSpeech: "adj",
    phonetic: "/ˈɡləʊ.bəl/",
    myanmarMeaning: "ကမ္ဘာလုံးဆိုင်ရာ",
    definition: "Relating to the whole world.",
    examples: ["Climate change is a global issue.", "The internet has created a global community."],
    synonyms: ["Worldwide", "International"]
  },
  "grateful": {
    word: "Grateful",
    partOfSpeech: "adj",
    phonetic: "/ˈɡreɪt.fəl/",
    myanmarMeaning: "ကျေးဇူးတင်သော",
    definition: "Showing or expressing thanks, especially to another person.",
    examples: ["I am grateful for your help.", "She was grateful for the opportunity."],
    synonyms: ["Thankful", "Appreciative"]
  },

  // --- H ---
  "habit": {
    word: "Habit",
    partOfSpeech: "noun",
    phonetic: "/ˈhæb.ɪt/",
    myanmarMeaning: "အလေ့အကျင့်",
    definition: "Something that you do often and regularly, sometimes without knowing that you are doing it.",
    examples: ["Reading is a good habit.", "It is hard to break a bad habit."],
    synonyms: ["Routine", "Custom"]
  },
  "healthy": {
    word: "Healthy",
    partOfSpeech: "adj",
    phonetic: "/ˈhel.θi/",
    myanmarMeaning: "ကျန်းမာသော",
    definition: "Strong and well, not ill.",
    examples: ["Eating vegetables is healthy.", "He looks very healthy."],
    synonyms: ["Fit", "Well"]
  },
  "history": {
    word: "History",
    partOfSpeech: "noun",
    phonetic: "/ˈhɪs.tər.i/",
    myanmarMeaning: "သမိုင်း",
    definition: "The study of or a record of past events.",
    examples: ["I like to study Myanmar history.", "Today's event will go down in history."],
    synonyms: ["Past", "Annals"]
  },

  // --- I ---
  "ignore": {
    word: "Ignore",
    partOfSpeech: "verb",
    phonetic: "/ɪɡˈnɔːr/",
    myanmarMeaning: "လျစ်လျူရှုသည်",
    definition: "To intentionally not listen to or give attention to someone or something.",
    examples: ["Don't ignore the warning signs.", "She ignored my advice."],
    synonyms: ["Disregard", "Neglect"]
  },
  "imagine": {
    word: "Imagine",
    partOfSpeech: "verb",
    phonetic: "/ɪˈmædʒ.ɪn/",
    myanmarMeaning: "စိတ်ကူးယဉ်သည် / ထင်မြင်သည်",
    definition: "To form or have a mental picture or idea of something.",
    examples: ["Imagine that you are on a beach in Ngapali.", "I can't imagine living in a cold country."],
    synonyms: ["Envision", "Picture"]
  },
  "improve": {
    word: "Improve",
    partOfSpeech: "verb",
    phonetic: "/ɪmˈpruːv/",
    myanmarMeaning: "တိုးတက်ကောင်းမွန်လာသည်",
    definition: "To get better, or to make something better.",
    examples: ["I want to improve my English speaking.", "The weather is starting to improve."],
    synonyms: ["Enhance", "Better"]
  },
  "independent": {
    word: "Independent",
    partOfSpeech: "adj",
    phonetic: "/ˌɪn.dɪˈpen.dənt/",
    myanmarMeaning: "လွတ်လပ်သော / ကိုယ့်ခြေထောက်ကိုယ်ရပ်တည်သော",
    definition: "Not influenced or controlled in any way by other people, events, or amounts.",
    examples: ["Myanmar became an independent nation in 1948.", "She is an independent woman."],
    synonyms: ["Free", "Self-reliant"]
  },

  // --- K ---
  "knowledge": {
    word: "Knowledge",
    partOfSpeech: "noun",
    phonetic: "/ˈnɒl.ɪdʒ/",
    myanmarMeaning: "ဗဟုသုတ / အသိပညာ",
    definition: "Understanding of or information about a subject that you get by experience or study.",
    examples: ["Reading books increases your knowledge.", "He has extensive knowledge of computers."],
    synonyms: ["Understanding", "Information"]
  },

  // --- L ---
  "language": {
    word: "Language",
    partOfSpeech: "noun",
    phonetic: "/ˈlæŋ.ɡwɪdʒ/",
    myanmarMeaning: "ဘာသာစကား",
    definition: "A system of communication used by a particular country or community.",
    examples: ["English is a global language.", "How many languages do you speak?"],
    synonyms: ["Speech", "Tongue"]
  },
  "luxury": {
    word: "Luxury",
    partOfSpeech: "noun",
    phonetic: "/ˈlʌk.ʃər.i/",
    myanmarMeaning: "ဇိမ်ခံပစ္စည်း / စည်းစိမ်",
    definition: "Great comfort, especially as provided by expensive and beautiful things.",
    examples: ["They live in luxury.", "A car is a luxury for many people."],
    synonyms: ["Opulence", "Comfort"]
  },

  // --- M ---
  "main": {
    word: "Main",
    partOfSpeech: "adj",
    phonetic: "/meɪn/",
    myanmarMeaning: "အဓိကကျသော",
    definition: "Larger, more important, or having more influence than others of the same type.",
    examples: ["The main reason for my visit is to see you.", "This is the main road to Mandalay."],
    synonyms: ["Primary", "Chief"]
  },
  "modern": {
    word: "Modern",
    partOfSpeech: "adj",
    phonetic: "/ˈmɒd.ən/",
    myanmarMeaning: "ခေတ်မီသော",
    definition: "Designed and made using the most recent ideas and methods.",
    examples: ["Yangon has many modern buildings.", "I like modern music."],
    synonyms: ["Contemporary", "Recent"]
  },

  // --- N ---
  "nature": {
    word: "Nature",
    partOfSpeech: "noun",
    phonetic: "/ˈneɪ.tʃər/",
    myanmarMeaning: "သဘာဝတရား",
    definition: "All the animals, plants, rocks, etc. in the world and all the features, forces, and processes that happen or exist independently of people.",
    examples: ["I love spending time in nature.", "We should live in harmony with nature."],
    synonyms: ["Environment"]
  },
  "negative": {
    word: "Negative",
    partOfSpeech: "adj",
    phonetic: "/ˈneɡ.ə.tɪv/",
    myanmarMeaning: "အနုတ်လက္ခဏာဆောင်သော / မကောင်းသော",
    definition: "Expressing 'no' or 'not', or not being positive or helpful.",
    examples: ["Try to avoid negative thoughts.", "The test result was negative."],
    synonyms: ["Bad", "Pessimistic"]
  },

  // --- O ---
  "opinion": {
    word: "Opinion",
    partOfSpeech: "noun",
    phonetic: "/əˈpɪn.jən/",
    myanmarMeaning: "ထင်မြင်ယူဆချက်",
    definition: "A thought or belief about something or someone.",
    examples: ["What is your opinion about this movie?", "In my opinion, learning English is fun."],
    synonyms: ["View", "Belief"]
  },
  "opportunity": {
    word: "Opportunity",
    partOfSpeech: "noun",
    phonetic: "/ˌɒp.əˈtjuː.nə.ti/",
    myanmarMeaning: "အခွင့်အလမ်း",
    definition: "An occasion or situation that makes it possible to do something that you want to do.",
    examples: ["Don't miss this opportunity to study abroad.", "A scholarship is a great opportunity."],
    synonyms: ["Chance", "Opening"]
  },

  // --- P ---
  "patience": {
    word: "Patience",
    partOfSpeech: "noun",
    phonetic: "/ˈpeɪ.ʃəns/",
    myanmarMeaning: "သည်းခံခြင်း / စိတ်ရှည်ခြင်း",
    definition: "The ability to wait, or to continue doing something despite difficulties.",
    examples: ["You need patience to learn a new skill.", "The teacher has a lot of patience."],
    synonyms: ["Tolerance", "Forbearance"]
  },
  "popular": {
    word: "Popular",
    partOfSpeech: "adj",
    phonetic: "/ˈpɒp.jə.lər/",
    myanmarMeaning: "လူကြိုက်များသော",
    definition: "Liked, enjoyed, or supported by many people.",
    examples: ["Football is a popular sport in Myanmar.", "This song is very popular."],
    synonyms: ["Famous", "Favored"]
  },

  // --- Q ---
  "quality": {
    word: "Quality",
    partOfSpeech: "noun",
    phonetic: "/ˈkwɒl.ə.ti/",
    myanmarMeaning: "အရည်အသွေး",
    definition: "How good or bad something is.",
    examples: ["We should focus on quality, not quantity.", "The quality of education is improving."],
    synonyms: ["Standard", "Grade"]
  },

  // --- R ---
  "reason": {
    word: "Reason",
    partOfSpeech: "noun",
    phonetic: "/ˈriː.zən/",
    myanmarMeaning: "အကြောင်းပြချက်",
    definition: "The cause of an event or situation or something that provides an excuse or explanation.",
    examples: ["What is the reason for your being late?", "I have a good reason for my decision."],
    synonyms: ["Cause", "Excuse"]
  },
  "respect": {
    word: "Respect",
    partOfSpeech: "verb",
    phonetic: "/rɪˈspekt/",
    myanmarMeaning: "လေးစားသည်",
    definition: "To feel or show admiration for someone or something that you believe has good ideas or qualities.",
    examples: ["We should respect our elders.", "I respect his honesty."],
    synonyms: ["Honor", "Admire"]
  },

  // --- S ---
  "success": {
    word: "Success",
    partOfSpeech: "noun",
    phonetic: "/səkˈses/",
    myanmarMeaning: "အောင်မြင်မှု",
    definition: "The achieving of the results wanted or hoped for.",
    examples: ["Hard work leads to success.", "We celebrated the success of our project."],
    synonyms: ["Triumph", "Achievement"]
  },
  "system": {
    word: "System",
    partOfSpeech: "noun",
    phonetic: "/ˈsɪs.təm/",
    myanmarMeaning: "စနစ်",
    definition: "A set of connected things or devices that operate together.",
    examples: ["The solar system is huge.", "We need a better system for learning."],
    synonyms: ["Structure", "Method"]
  },

  // --- T ---
  "traditional": {
    word: "Traditional",
    partOfSpeech: "adj",
    phonetic: "/trəˈdɪʃ.ən.əl/",
    myanmarMeaning: "ရိုးရာဓလေ့ထုံးတမ်းစဉ်လာအရ",
    definition: "Following or belonging to the customs or ways of behaving that have continued in a group of people for a long time.",
    examples: ["Longyi is a traditional dress in Myanmar.", "I like traditional festivals."],
    synonyms: ["Conventional", "Classic"]
  },
  "truth": {
    word: "Truth",
    partOfSpeech: "noun",
    phonetic: "/truːθ/",
    myanmarMeaning: "အမှန်တရား",
    definition: "The real facts about a situation, event, or person.",
    examples: ["Please tell the truth.", "The truth will come out eventually."],
    synonyms: ["Fact", "Reality"]
  },

  // --- U ---
  "understand": {
    word: "Understand",
    partOfSpeech: "verb",
    phonetic: "/ˌʌn.dəˈstænd/",
    myanmarMeaning: "နားလည်သည်",
    definition: "To know the meaning of something that someone says.",
    examples: ["I understand English very well.", "Do you understand the lesson?"],
    synonyms: ["Comprehend", "Grasp"]
  },
  "unique": {
    word: "Unique",
    partOfSpeech: "adj",
    phonetic: "/juːˈniːk/",
    myanmarMeaning: "ထူးခြားသော / တစ်ခုတည်းသာရှိသော",
    definition: "Being the only existing one of its type or, more generally, unusual, or special in some way.",
    examples: ["Inle Lake is a unique place in Myanmar.", "Every person is unique."],
    synonyms: ["Distinctive", "Special"]
  },

  // --- V ---
  "vocabulary": {
    word: "Vocabulary",
    partOfSpeech: "noun",
    phonetic: "/vəˈkæb.jə.ler.i/",
    myanmarMeaning: "ဝေါဟာရ",
    definition: "All the words that exist in a particular language or subject.",
    examples: ["Reading helps to improve your vocabulary.", "I learn ten new vocabulary words every day."],
    synonyms: ["Terminology", "Lexicon"]
  },

  // --- W ---
  "wonderful": {
    word: "Wonderful",
    partOfSpeech: "adj",
    phonetic: "/ˈwʌn.də.fəl/",
    myanmarMeaning: "အံ့သြဖွယ်ကောင်းသော / အလွန်ကောင်းမွန်သော",
    definition: "Extremely good.",
    examples: ["The sunset at Bagan was wonderful.", "Have a wonderful day!"],
    synonyms: ["Amazing", "Great"]
  }
};
