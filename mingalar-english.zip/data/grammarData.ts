
import { GrammarLesson } from "../types";

export const RICH_GRAMMAR_LESSONS: Record<string, GrammarLesson> = {
  // ==========================================
  // PRIMARY SCHOOL PATH (Foundation - Beginner)
  // ==========================================
  "p-alphabet-cap": {
    id: "p-alphabet-cap",
    title: "1. Alphabet & Big Letters",
    category: "Structure",
    difficulty: "Beginner",
    description: "When to use Capital Letters (A, B, C).",
    explanation: "English sentences must start with a Capital letter. Specific names of people, places, and the word 'I' are always capitalized.",
    summary: "Sentence Start + Names + 'I' = Capital Letter.",
    myanmarExplanation: "အင်္ဂလိပ်စာတွင် ဝါကျတစ်ခုအစ၊ လူအမည်၊ မြို့အမည်နှင့် 'I' (ကျွန်တော်/ကျွန်မ) တို့ကို ရေးသားရာတွင် အက္ခရာအကြီး (Capital Letter) ဖြင့် အမြဲရေးရမည်။",
    relatedQuizLevel: 1,
    examples: [
      { english: "I live in Yangon.", myanmar: "ကျွန်တော် ရန်ကုန်မှာ နေပါတယ်။" },
      { english: "My friend is Su Su.", myanmar: "ကျွန်တော့်သူငယ်ချင်းက စုစုပါ။" }
    ],
    commonMistakes: [
      { wrong: "he is my friend", right: "He is my friend.", reason: "Myanmar script doesn't have capital letters, so students often forget that English sentences MUST start with one." },
      { wrong: "i am a student.", right: "I am a student.", reason: "In English, the word 'I' (ကျွန်တော်/မ) is a VIP. It is ALWAYS a capital letter, even in the middle of a sentence." }
    ],
    tips: [
      "The letter 'I' is always big because you are important!",
      "A full stop (.) at the end of a sentence is like a stop sign; the next word must start with a Capital Letter."
    ],
    practice: [
      {
        id: "p1_1",
        question: "Sentence Correction: Choose the correct sentence.",
        options: ["she is happy", "She is Happy", "She is happy."],
        correctIndex: 2,
        explanation: "Every sentence must start with a Capital letter and end with a full stop."
      }
    ]
  },
  "p-nouns-basic": {
    id: "p-nouns-basic",
    title: "2. Nouns (Naming Words)",
    category: "Parts of Speech",
    difficulty: "Beginner",
    description: "Learning common and proper nouns.",
    explanation: "Nouns are names of people, places, things, or animals. Proper nouns (Yangon, Maung Maung) always start with a capital letter.",
    summary: "Nouns = Names of People, Places, or Things.",
    myanmarExplanation: "နာမ် (Noun) ဆိုတာ လူ၊ တိရစ္ဆာန်၊ နေရာနဲ့ အရာဝတ္ထုတွေရဲ့ အမည်တွေဖြစ်ပါတယ်။",
    relatedQuizLevel: 1,
    examples: [
      { english: "The cat is on the table.", myanmar: "ကြောင်က စားပွဲပေါ်မှာ။" },
      { english: "Mandalay is a city.", myanmar: "မန္တလေးက မြို့တစ်မြို့ပါ။" }
    ],
    commonMistakes: [
      { wrong: "i love yangon.", right: "I love Yangon.", reason: "City names are Proper Nouns and must be capitalized." }
    ],
    tips: [
      "If you can touch it or see it, it is usually a noun."
    ],
    practice: [
      {
        id: "p2_1",
        question: "Which word is a noun?",
        options: ["Run", "Happy", "Chair"],
        correctIndex: 2,
        explanation: "'Chair' is a thing."
      }
    ]
  },
  "p-pronouns": {
    id: "p-pronouns",
    title: "3. He, She, and It",
    category: "Parts of Speech",
    difficulty: "Beginner",
    description: "Using Pronouns correctly for gender.",
    explanation: "Pronouns replace names. Use 'He' for males, 'She' for females, and 'It' for objects or animals.",
    summary: "He = Boy | She = Girl | It = Thing.",
    myanmarExplanation: "မြန်မာစကားမှာ 'သူ' ကို ကျား/မ နှစ်မျိုးလုံး သုံးပေမယ့် အင်္ဂလိပ်စာမှာတော့ ယောကျ်ားလေးဆိုရင် 'He'၊ မိန်းကလေးဆိုရင် 'She' ကို ခွဲသုံးရပါတယ်။",
    relatedQuizLevel: 2,
    examples: [
      { english: "He is my father.", myanmar: "သူက ကျွန်တော့်အဖေပါ။" },
      { english: "She is a teacher.", myanmar: "သူမက ဆရာမတစ်ယောက်ပါ။" }
    ],
    commonMistakes: [
      { wrong: "My sister is tall. He is kind.", right: "My sister is tall. She is kind.", reason: "Don't use 'He' for girls!" }
    ],
    tips: [
      "Think: Is it a boy? Use He. Is it a girl? Use She."
    ],
    practice: [
      {
        id: "p3_1",
        question: "Mya Mya is a nurse. ___ works in a hospital.",
        options: ["He", "She", "It"],
        correctIndex: 1,
        explanation: "Mya Mya is a girl's name."
      }
    ]
  },
  "p-plurals": {
    id: "p-plurals",
    title: "4. Plurals (One or Many)",
    category: "Parts of Speech",
    difficulty: "Beginner",
    description: "Adding -s and -es to nouns.",
    explanation: "To show there is more than one, we usually add -s to the noun. If a word ends in s, x, ch, or sh, add -es.",
    summary: "One cat -> Two cats | One box -> Two boxes.",
    myanmarExplanation: "အင်္ဂလိပ်စာမှာ တစ်ခုထက်ပိုရင် နာမ်နောက်မှာ -s (သို့မဟုတ်) -es ပေါင်းရပါတယ်။ မြန်မာစကားမှာ '...တွေ' လို့ ပေါင်းသလိုပါပဲ။",
    relatedQuizLevel: 2,
    examples: [
      { english: "I have two pens.", myanmar: "ကျွန်တော့်မှာ ဘောပင်နှစ်ချောင်းရှိတယ်။" },
      { english: "She has three apples.", myanmar: "သူမမှာ ပန်းသီးသုံးလုံးရှိတယ်။" }
    ],
    commonMistakes: [
      { wrong: "There are two child.", right: "There are two children.", reason: "Some words are irregular. They don't just add -s." }
    ],
    tips: [
      "Always look for numbers (two, three, many). If you see them, the noun usually needs an -s."
    ],
    practice: [
      {
        id: "p4_1",
        question: "What is the plural of 'Bus'?",
        options: ["Buss", "Buses", "Busies"],
        correctIndex: 1,
        explanation: "Words ending in -s need -es."
      }
    ]
  },
  "p-this-that": {
    id: "p-this-that",
    title: "5. This, That, These, Those",
    category: "Structure",
    difficulty: "Beginner",
    description: "Pointing at things near and far.",
    explanation: "Use 'This' (singular) and 'These' (plural) for things near you. Use 'That' (singular) and 'Those' (plural) for things far away.",
    summary: "This/These = Near | That/Those = Far.",
    myanmarExplanation: "အနီးမှာရှိရင် This/These (ဒါ/ဒါတွေ) ကိုသုံးပြီး အဝေးမှာရှိရင် That/Those (ဟိုဟာ/ဟိုဟာတွေ) ကို သုံးပါတယ်။",
    relatedQuizLevel: 2,
    examples: [
      { english: "This is my book.", myanmar: "ဒါ ကျွန်တော့်စာအုပ်ပါ။" },
      { english: "Those are stars.", myanmar: "ဟိုဟာတွေက ကြယ်တွေပါ။" }
    ],
    commonMistakes: [
      { wrong: "This is my pens.", right: "These are my pens.", reason: "Use 'These' for more than one thing near you." }
    ],
    tips: [
      "Touch it? Use This. Point at it far away? Use That."
    ],
    practice: [
      {
        id: "p5_1",
        question: "___ (far) are my friends.",
        options: ["This", "That", "Those"],
        correctIndex: 2,
        explanation: "'Those' is for plural far away."
      }
    ]
  },
  "p-articles": {
    id: "p-articles",
    title: "6. A, An, and The",
    category: "Parts of Speech",
    difficulty: "Beginner",
    description: "How to use articles correctly.",
    explanation: "Use 'a' for consonant sounds. Use 'an' for vowel sounds (a,e,i,o,u). Use 'the' when we know exactly which thing we are talking about.",
    summary: "A/An = One (General) | The = Specific.",
    myanmarExplanation: "တစ်ခုတည်းရှိတာကို ပြောရင် A/An သုံးပါတယ်။ သရသံ (a,e,i,o,u) ဆိုရင် An သုံးပါ။ အတိအကျညွှန်ပြရင် The သုံးပါ။",
    relatedQuizLevel: 2,
    examples: [
      { english: "I eat an egg.", myanmar: "ကျွန်တော် ကြက်ဥတစ်လုံးစားတယ်။" },
      { english: "Open the door.", myanmar: "တံခါးကို ဖွင့်လိုက်ပါ။" }
    ],
    commonMistakes: [
      { wrong: "I want a apple.", right: "I want an apple.", reason: "Apple starts with a vowel sound 'A'." }
    ],
    tips: [
      "Listen to the sound! 'Hour' starts with H but sounds like O, so we say 'an hour'."
    ],
    practice: [
      {
        id: "p6_1",
        question: "I see ___ big elephant.",
        options: ["a", "an", "the"],
        correctIndex: 0,
        explanation: "'Big' starts with a consonant sound."
      }
    ]
  },
  "p-prepositions-basic": {
    id: "p-prepositions-basic",
    title: "7. Basic Prepositions (In, On, Under)",
    category: "Parts of Speech",
    difficulty: "Beginner",
    description: "Describing where things are.",
    explanation: "Use 'In' for inside, 'On' for on top of, and 'Under' for below something.",
    summary: "In = ထဲမှာ | On = ပေါ်မှာ | Under = အောက်မှာ.",
    myanmarExplanation: "ပစ္စည်းတစ်ခု ဘယ်နေရာမှာရှိလဲဆိုတာကို ပြောပြဖို့ သုံးပါတယ်။",
    relatedQuizLevel: 2,
    examples: [
      { english: "The key is in the box.", myanmar: "သော့က သေတ္တာထဲမှာ။" },
      { english: "The cat is under the chair.", myanmar: "ကြောင်က ကုလားထိုင်အောက်မှာ။" }
    ],
    commonMistakes: [
      { wrong: "I am on the room.", right: "I am in the room.", reason: "You are inside the space, so use 'in'." }
    ],
    tips: [
      "Use 'On' when two things are touching surface-to-surface."
    ],
    practice: [
      {
        id: "p7_1",
        question: "The book is ___ the table.",
        options: ["in", "on", "under"],
        correctIndex: 1,
        explanation: "Books sit on surfaces."
      }
    ]
  },
  "p-conjunctions": {
    id: "p-conjunctions",
    title: "8. And, But, Or",
    category: "Parts of Speech",
    difficulty: "Beginner",
    description: "Connecting words and sentences.",
    explanation: "Conjunctions are connecting words. Use 'and' for addition, 'but' for contrast, and 'or' for choice.",
    summary: "And (+) | But (Difference) | Or (Choice).",
    myanmarExplanation: "စကားလုံးတွေကို ဆက်သွယ်ပေးတဲ့ စကားဆက်များ ဖြစ်ပါတယ်။ 'and' (နှင့်)၊ 'but' (သို့သော်)၊ 'or' (သို့မဟုတ်) တို့ကို အသုံးအများဆုံး ဖြစ်ပါတယ်။",
    relatedQuizLevel: 1,
    examples: [
      { english: "I like tea and coffee.", myanmar: "ကျွန်တော် လက်ဖက်ရည်နဲ့ ကော်ဖီ ကြိုက်တယ်။" },
      { english: "I want to go, but I am tired.", myanmar: "ကျွန်တော် သွားချင်တယ်၊ ဒါပေမယ့် ပင်ပန်းနေတယ်။" },
      { english: "Do you want water or juice?", myanmar: "မင်း ရေလား ဒါမှမဟုတ် ဖျော်ရည်လား ဘာသောက်မလဲ?" }
    ],
    commonMistakes: [
      { wrong: "I like apple but I like orange.", right: "I like apple and I like orange.", reason: "Use 'and' when both things are positive/similar." }
    ],
    tips: [
      "Use a comma before 'but' when joining two complete sentences."
    ],
    practice: [
      {
        id: "p8_1",
        question: "He is small ___ he is strong.",
        options: ["and", "but", "or"],
        correctIndex: 1,
        explanation: "Small and strong are contrasting ideas."
      }
    ]
  },
  "p-adjectives": {
    id: "p-adjectives",
    title: "9. Describing Words (Adjectives)",
    category: "Parts of Speech",
    difficulty: "Beginner",
    description: "Words that describe color, size, and shape.",
    explanation: "Adjectives give more information about nouns. In English, adjectives usually come BEFORE the noun.",
    summary: "Adjective + Noun (e.g. Red apple).",
    myanmarExplanation: "နာမ်တွေရဲ့ အရောင်၊ အရွယ်အစား၊ အခြေအနေတွေကို ဖော်ပြပေးတဲ့ စကားလုံးတွေဖြစ်ပါတယ်။ မြန်မာစကားမှာလိုပဲ နာမ်ရဲ့ ရှေ့မှာ ထားသုံးရပါတယ်။",
    relatedQuizLevel: 1,
    examples: [
      { english: "A big dog.", myanmar: "ခွေးအကြီးကြီးတစ်ကောင်။" },
      { english: "The sky is blue.", myanmar: "ကောင်းကင်ကြီးက ပြာနေတယ်။" }
    ],
    commonMistakes: [
      { wrong: "The car red.", right: "The red car.", reason: "Adjectives usually go before the noun." }
    ],
    tips: [
      "Adjectives don't have plural forms. Don't say 'bigs dogs'."
    ],
    practice: [
      {
        id: "p9_1",
        question: "Find the adjective: 'The beautiful flower is in the garden.'",
        options: ["Garden", "Flower", "Beautiful"],
        correctIndex: 2,
        explanation: "'Beautiful' describes the flower."
      }
    ]
  },

  // ==========================================
  // MIDDLE SCHOOL PATH (Intermediate - Functional)
  // ==========================================
  "m-present-tenses": {
    id: "m-present-tenses",
    title: "10. Simple vs Continuous",
    category: "Tenses",
    difficulty: "Intermediate",
    description: "Everyday habits vs. what's happening now.",
    explanation: "Present Simple (I eat) is for habits. Present Continuous (I am eating) is for actions happening exactly now.",
    summary: "Every day = Simple | Now = Continuous.",
    myanmarExplanation: "နေ့တိုင်းလုပ်တဲ့အရာတွေအတွက် Simple သုံးပြီး၊ အခုလုပ်နေဆဲအရာတွေအတွက် Continuous (...နေသည်) ကို သုံးပါတယ်။",
    relatedQuizLevel: 3,
    examples: [
      { english: "I play football every Sunday.", myanmar: "ကျွန်တော် တနင်္ဂနွေနေ့တိုင်း ဘောလုံးကန်တယ်။" },
      { english: "I am playing football now.", myanmar: "ကျွန်တော် အခု ဘောလုံးကန်နေတယ်။" }
    ],
    commonMistakes: [
      { wrong: "I am play football every day.", right: "I play football every day.", reason: "Don't use 'am' for regular habits." }
    ],
    tips: [
      "Look for words like 'now', 'at the moment' or 'Look!'. They mean use -ing."
    ],
    practice: [
      {
        id: "m8_1",
        question: "Listen! She ___ a song.",
        options: ["sings", "is singing", "sing"],
        correctIndex: 1,
        explanation: "'Listen!' means it's happening now."
      }
    ]
  },
  "m-past-simple": {
    id: "m-past-simple",
    title: "11. Past Simple (The Past)",
    category: "Tenses",
    difficulty: "Intermediate",
    description: "Talking about things that are finished.",
    explanation: "Use the past form (V2) for finished actions. Regular verbs add -ed (played). Irregular verbs change (go -> went).",
    summary: "Past Simple = Finished action.",
    myanmarExplanation: "ပြီးဆုံးသွားတဲ့ အတိတ်ကအရာတွေအတွက် သုံးပါတယ်။ မြန်မာလို '...ခဲ့သည်' လို့ အဓိပ္ပာယ်ရပါတယ်။",
    relatedQuizLevel: 3,
    examples: [
      { english: "I visited Bagan last year.", myanmar: "ကျွန်တော် မနှစ်က ပုဂံကို သွားခဲ့တယ်။" },
      { english: "He ate rice two hours ago.", myanmar: "သူ လွန်ခဲ့တဲ့ နှစ်နာရီက ထမင်းစားခဲ့တယ်။" }
    ],
    commonMistakes: [
      { wrong: "I go to school yesterday.", right: "I went to school yesterday.", reason: "Yesterday is in the past. You must use 'went'." }
    ],
    tips: [
      "Signal words: Yesterday, Last week, ...ago, In 2010."
    ],
    practice: [
      {
        id: "m9_1",
        question: "We ___ a movie last night.",
        options: ["watch", "watched", "watching"],
        correctIndex: 1,
        explanation: "'Last night' is past."
      }
    ]
  },
  "m-future": {
    id: "m-future",
    title: "12. Will and Going To",
    category: "Tenses",
    difficulty: "Intermediate",
    description: "Talking about the future.",
    explanation: "Use 'Will' for quick decisions or promises. Use 'Be going to' for plans you already made.",
    summary: "Will = Quick | Going to = Planned.",
    myanmarExplanation: "နောင်အနာဂတ် (လုပ်မယ်) ဆိုတာကို ပြောဖို့ သုံးပါတယ်။ စီစဉ်ထားပြီးသားဆိုရင် 'Going to' သုံးပါ။",
    relatedQuizLevel: 4,
    examples: [
      { english: "I will help you.", myanmar: "ကျွန်တော် မင်းကို ကူညီပါ့မယ်။" },
      { english: "I am going to visit my aunt tomorrow.", myanmar: "ကျွန်တော် မနက်ဖြန် အဒေါ်ဆီ သွားလည်ဖို့ စီစဉ်ထားတယ်။" }
    ],
    commonMistakes: [
      { wrong: "I going to Yangon.", right: "I am going to Yangon.", reason: "Don't forget the 'am/is/are' before 'going to'." }
    ],
    tips: [
      "Use 'Will' when you decide something right now."
    ],
    practice: [
      {
        id: "m10_1",
        question: "The phone is ringing. I ___ answer it.",
        options: ["will", "going to", "am"],
        correctIndex: 0,
        explanation: "Quick decision."
      }
    ]
  },
  "m-comparatives": {
    id: "m-comparatives",
    title: "13. Comparing Things",
    category: "Parts of Speech",
    difficulty: "Intermediate",
    description: "Using -er and more.",
    explanation: "For short words, add -er (faster). For long words, use 'more' (more beautiful). Use 'than' to connect.",
    summary: "Short-er than | More long-word than.",
    myanmarExplanation: "အရာနှစ်ခုကို နှိုင်းယှဉ်တဲ့အခါ သုံးပါတယ်။ 'ထက်ပိုပြီး...' လို့ အဓိပ္ပာယ်ရပါတယ်။",
    relatedQuizLevel: 4,
    examples: [
      { english: "A bus is bigger than a car.", myanmar: "ဘတ်စ်ကားက ကားထက် ပိုကြီးတယ်။" },
      { english: "Gold is more expensive than silver.", myanmar: "ရွှေက ငွေထက် ပိုစျေးကြီးတယ်။" }
    ],
    commonMistakes: [
      { wrong: "He is more faster than me.", right: "He is faster than me.", reason: "Don't use 'more' and '-er' at the same time!" }
    ],
    tips: [
      "Always use 'than' after the comparative word."
    ],
    practice: [
      {
        id: "m11_1",
        question: "English is ___ than math.",
        options: ["easyer", "easier", "more easy"],
        correctIndex: 1,
        explanation: "Short words ending in -y change to -ier."
      }
    ]
  },
  "m-quantifiers": {
    id: "m-quantifiers",
    title: "14. Much, Many, Some, Any",
    category: "Parts of Speech",
    difficulty: "Intermediate",
    description: "How much or how many.",
    explanation: "Use 'Many' for things you can count (books). Use 'Much' for things you cannot count (water). Use 'Some' in (+) sentences and 'Any' in (-) or (?) sentences.",
    summary: "Many (Count) | Much (Uncount).",
    myanmarExplanation: "အရေအတွက်နဲ့ ပမာဏကို ဖော်ပြဖို့ သုံးပါတယ်။ ရေတွက်လို့ရတဲ့အရာတွေအတွက် Many သုံးပြီး ရေတွက်လို့မရတဲ့အရာ (ရေ၊ ဆန်) အတွက် Much သုံးပါ။",
    relatedQuizLevel: 4,
    examples: [
      { english: "I have many friends.", myanmar: "ကျွန်တော့်မှာ သူငယ်ချင်း အများကြီးရှိတယ်။" },
      { english: "I don't have much money.", myanmar: "ကျွန်တော့်မှာ ပိုက်ဆံ အများကြီးမရှိဘူး။" }
    ],
    commonMistakes: [
      { wrong: "How many water do you want?", right: "How much water do you want?", reason: "Water is uncountable." }
    ],
    tips: [
      "If you can add an 's' to the word (cats, pens), use 'many'."
    ],
    practice: [
      {
        id: "m12_1",
        question: "Do you have ___ milk?",
        options: ["some", "any", "many"],
        correctIndex: 1,
        explanation: "Use 'any' for questions."
      }
    ]
  },
  "m-modal-verbs": {
    id: "m-modal-verbs",
    title: "15. Modal Verbs (Ability & Advice)",
    category: "Parts of Speech",
    difficulty: "Intermediate",
    description: "Can, Could, Should, Must.",
    explanation: "Modal verbs are helper verbs. Use 'can' for ability, 'should' for advice, and 'must' for rules.",
    summary: "Can (Ability) | Should (Advice) | Must (Rule).",
    myanmarExplanation: "ကြိယာကို အကူအညီပေးတဲ့ စကားလုံးတွေဖြစ်ပါတယ်။ တတ်နိုင်ခြင်း၊ အကြံပေးခြင်းနဲ့ စည်းကမ်းတွေကို ဖော်ပြတဲ့အခါ သုံးပါတယ်။",
    relatedQuizLevel: 4,
    examples: [
      { english: "I can speak English.", myanmar: "ကျွန်တော် အင်္ဂလိပ်စကား ပြောတတ်တယ်။" },
      { english: "You should sleep early.", myanmar: "မင်း စောစောအိပ်သင့်တယ်။" },
      { english: "We must wear masks.", myanmar: "ကျွန်တော်တို့ Mask တပ်ရမယ်။" }
    ],
    commonMistakes: [
      { wrong: "I can to swim.", right: "I can swim.", reason: "Don't use 'to' after modal verbs (except have to/ought to)." },
      { wrong: "He cans sing.", right: "He can sing.", reason: "Modal verbs never add 's' for third person." }
    ],
    tips: [
      "After a modal verb, always use the base form of the verb (V1)."
    ],
    practice: [
      {
        id: "m15_1",
        question: "You ___ brush your teeth twice a day.",
        options: ["can", "should", "must"],
        correctIndex: 1,
        explanation: "This is good advice."
      }
    ]
  },
  "m-adverbs": {
    id: "m-adverbs",
    title: "16. Adverbs of Manner (-ly)",
    category: "Parts of Speech",
    difficulty: "Intermediate",
    description: "Describing how an action is done.",
    explanation: "Adverbs of manner tell us HOW an action happens. Most adverbs are formed by adding -ly to an adjective.",
    summary: "Verb + Adverb (e.g. Speak slowly).",
    myanmarExplanation: "လုပ်ဆောင်ချက်တစ်ခုကို ဘယ်လိုပုံစံနဲ့ လုပ်ဆောင်သလဲဆိုတာကို ဖော်ပြပေးတာပါ။ များသောအားဖြင့် နာမဝိသေသနနောက်မှာ -ly ပေါင်းပြီး သုံးပါတယ်။",
    relatedQuizLevel: 4,
    examples: [
      { english: "He runs quickly.", myanmar: "သူ မြန်မြန်ပြေးတယ်။" },
      { english: "She speaks softly.", myanmar: "သူမ လေသံတိုးတိုးနဲ့ ပြောတယ်။" }
    ],
    commonMistakes: [
      { wrong: "He speaks good.", right: "He speaks well.", reason: "Use the adverb 'well', not the adjective 'good' to describe how someone speaks." }
    ],
    tips: [
      "Some adverbs are irregular: Fast -> Fast, Hard -> Hard."
    ],
    practice: [
      {
        id: "m16_1",
        question: "Please write ___ so I can read it.",
        options: ["clear", "clearly", "more clear"],
        correctIndex: 1,
        explanation: "Clearly describes how to write."
      }
    ]
  },

  // ==========================================
  // HIGH SCHOOL PATH (Advanced - Exam Focus)
  // ==========================================
  "h-present-perfect": {
    id: "h-present-perfect",
    title: "17. Present Perfect",
    category: "Tenses",
    difficulty: "Advanced",
    description: "Actions that connect the past and now.",
    explanation: "Use Have/Has + Verb 3. Use it for experiences or things that happened at an unknown time.",
    summary: "Have/Has + V3.",
    myanmarExplanation: "အတိတ်ကနေ အခုအထိ သက်ရောက်မှုရှိနေတဲ့ အရာတွေ (ဥပမာ- လုပ်ဖူးတယ်၊ ပြီးသွားပြီ) ကို ပြောဖို့ သုံးပါတယ်။",
    relatedQuizLevel: 5,
    examples: [
      { english: "I have seen that movie.", myanmar: "ကျွန်တော် အဲဒီကား ကြည့်ဖူးတယ်။" },
      { english: "She has finished her homework.", myanmar: "သူမ အိမ်စာ ပြီးသွားပြီ။" }
    ],
    commonMistakes: [
      { wrong: "I have see her yesterday.", right: "I saw her yesterday.", reason: "If you say 'yesterday' (exact time), use Past Simple, not Present Perfect." }
    ],
    tips: [
      "Use 'Just' for things that finished 1 minute ago."
    ],
    practice: [
      {
        id: "h13_1",
        question: "___ you ever been to Bagan?",
        options: ["Do", "Did", "Have"],
        correctIndex: 2,
        explanation: "Questions about experience use 'Have'."
      }
    ]
  },
  "h-passive-voice": {
    id: "h-passive-voice",
    title: "18. Passive Voice",
    category: "Structure",
    difficulty: "Advanced",
    description: "Focusing on the action, not the doer.",
    explanation: "Passive voice focuses on the object. Form: Be + Verb 3. Example: The letter was sent.",
    summary: "Object + Be + V3.",
    myanmarExplanation: "ပြုလုပ်သူထက် အလုပ်ခံရသူကို အသားပေးချင်တဲ့အခါ သုံးပါတယ်။ မြန်မာလို '...ခြင်းခံရသည်' လို့ အဓိပ္ပာယ်ရပါတယ်။",
    relatedQuizLevel: 5,
    examples: [
      { english: "The road was built in 1990.", myanmar: "ဒီလမ်းကို ၁၉၉၀ မှာ တည်ဆောက်ခဲ့တာပါ။" },
      { english: "Rice is grown in Myanmar.", myanmar: "မြန်မာနိုင်ငံမှာ ဆန်စပါးကို စိုက်ပျိုးပါတယ်။" }
    ],
    commonMistakes: [
      { wrong: "The window broken.", right: "The window was broken.", reason: "Passive needs the 'be' verb (was/is)." }
    ],
    tips: [
      "Use the 'by' phrase only if the person who did the action is important."
    ],
    practice: [
      {
        id: "h14_1",
        question: "Active: 'He stole my bag.' -> Passive: 'My bag ___.'",
        options: ["stole", "was stolen", "is stole"],
        correctIndex: 1,
        explanation: "Past passive needs was + V3."
      }
    ]
  },
  "h-conditionals": {
    id: "h-conditionals",
    title: "19. Conditionals (If Clauses)",
    category: "Advanced",
    difficulty: "Advanced",
    description: "Talking about 'If' situations.",
    explanation: "Type 1: If it rains, I will stay (Real). Type 2: If I were rich, I would buy a car (Imaginary).",
    summary: "If + Condition, Result.",
    myanmarExplanation: "အခြေအနေတစ်ခုခု ဖြစ်ခဲ့ရင်... ဆိုတဲ့ အဓိပ္ပာယ်ပါ။ အဆင့် ၃ ဆင့် ရှိပါတယ်။",
    relatedQuizLevel: 5,
    examples: [
      { english: "If you study, you will pass.", myanmar: "မင်းစာကြိုးစားရင် အောင်လိမ့်မယ်။" },
      { english: "If I were you, I would go.", myanmar: "ငါသာ မင်းနေရာမှာဆိုရင် သွားလိုက်မယ်။" }
    ],
    commonMistakes: [
      { wrong: "If I will go, I tell you.", right: "If I go, I will tell you.", reason: "Don't use 'will' inside the 'if' part." }
    ],
    tips: [
      "Type 1 is for likely futures. Type 2 is for dreaming or unlikely situations."
    ],
    practice: [
      {
        id: "h15_1",
        question: "If I ___ money, I would buy that phone.",
        options: ["have", "had", "will have"],
        correctIndex: 1,
        explanation: "Type 2 uses Past Simple in the 'if' clause."
      }
    ]
  },
  "h-gerunds": {
    id: "h-gerunds",
    title: "20. Gerunds vs Infinitives",
    category: "Advanced",
    difficulty: "Advanced",
    description: "Using -ing or 'to' after verbs.",
    explanation: "Some verbs need -ing (I enjoy swimming). Some verbs need 'to' (I want to go).",
    summary: "Verb + -ing OR Verb + to + V1.",
    myanmarExplanation: "ကြိယာနှစ်ခု ဆက်တိုက်သုံးတဲ့အခါ နောက်ကကြိယာကို -ing ပေါင်းမလား၊ ရှေ့က to ခံမလားဆိုတာကို ခွဲခြားတတ်ဖို့ပါ။",
    relatedQuizLevel: 5,
    examples: [
      { english: "I like listening to music.", myanmar: "ကျွန်တော် သီချင်းနားထောင်ရတာ ကြိုက်တယ်။" },
      { english: "She promised to help me.", myanmar: "သူမ ကျွန်တော့်ကို ကူညီဖို့ ကတိပေးခဲ့တယ်။" }
    ],
    commonMistakes: [
      { wrong: "I want going home.", right: "I want to go home.", reason: "'Want' is followed by 'to'." }
    ],
    tips: [
      "When a verb follows a preposition, it is almost always a Gerund (-ing)."
    ],
    practice: [
      {
        id: "h16_1",
        question: "He finished ___ his homework.",
        options: ["to do", "doing", "do"],
        correctIndex: 1,
        explanation: "'Finish' is followed by -ing."
      }
    ]
  },
  "h-phrasal-verbs": {
    id: "h-phrasal-verbs",
    title: "21. Phrasal Verbs",
    category: "Advanced",
    difficulty: "Advanced",
    description: "Verbs with small words (up, in, out).",
    explanation: "A phrasal verb is a verb + preposition. The meaning changes! (Look = ကြည့်သည်, Look for = ရှာဖွေသည်).",
    summary: "Verb + Particle = New Meaning.",
    myanmarExplanation: "ကြိယာတစ်ခုနဲ့ ဝိဘတ်တစ်ခုပေါင်းပြီး အဓိပ္ပာယ်အသစ်တစ်ခု ထွက်ပေါ်လာတာပါ။ အင်္ဂလိပ်စကားပြောမှာ အသုံးအရမ်းများပါတယ်။",
    relatedQuizLevel: 5,
    examples: [
      { english: "I wake up at 6 AM.", myanmar: "ကျွန်တော် မနက် ၆ နာရီမှာ အိပ်ရာထတယ်။" },
      { english: "Please turn off the lights.", myanmar: "မီးပိတ်ပေးပါ။" }
    ],
    commonMistakes: [
      { wrong: "I'm looking my keys.", right: "I'm looking for my keys.", reason: "To search, you must say 'look for'." }
    ],
    tips: [
      "Learn them as one word, not two separate words."
    ],
    practice: [
      {
        id: "h17_1",
        question: "The car ___ down on the way to Mandalay.",
        options: ["broke", "fell", "cut"],
        correctIndex: 0,
        explanation: "'Break down' means the machine stopped working."
      }
    ]
  },
  "h-linking-words": {
    id: "h-linking-words",
    title: "22. Linking Words",
    category: "Writing",
    difficulty: "Advanced",
    description: "Connecting your ideas.",
    explanation: "Use words like 'However', 'Therefore', 'Moreover' to connect sentences and show logic.",
    summary: "However (But) | Therefore (So).",
    myanmarExplanation: "ဝါကျတွေကို ပိုပြီး အဆင့်မြင့်အောင် ပေါင်းစပ်တဲ့အခါ သုံးပါတယ်။ အက်ဆေး (Essay) ရေးတဲ့အခါ အသုံးဝင်ပါတယ်။",
    relatedQuizLevel: 5,
    examples: [
      { english: "It was raining. However, we went out.", myanmar: "မိုးရွာနေတယ်။ ဒါပေမယ့် ကျွန်တော်တို့ အပြင်ထွက်ခဲ့ကြတယ်။" },
      { english: "He studied hard. Therefore, he passed.", myanmar: "သူစာကြိုးစားခဲ့တယ်။ ဒါကြောင့် သူအောင်ခဲ့တယ်။" }
    ],
    commonMistakes: [
      { 
        wrong: "I like tea, however I hate coffee.", 
        right: "I like tea. However, I hate coffee.", 
        reason: "However needs to start a new sentence or be used after a semicolon." 
      }
    ],
    tips: [
      "Linking words help your writing sound more professional and organized."
    ],
    practice: [
      {
        id: "h18_1",
        question: "The food was expensive. ___, it wasn't very good.",
        options: ["Moreover", "However", "Therefore"],
        correctIndex: 1,
        explanation: "Contrast between price and quality."
      }
    ]
  },
  "h-reported-speech": {
    id: "h-reported-speech",
    title: "23. Reported Speech",
    category: "Advanced",
    difficulty: "Advanced",
    description: "Reporting what others said.",
    explanation: "Reported speech is when we tell someone what another person said. Usually, we change the tense back (Present -> Past).",
    summary: "Said that + Backshift tense.",
    myanmarExplanation: "တစ်ဦးတစ်ယောက် ပြောခဲ့တဲ့ စကားကို နောက်တစ်ယောက်ဆီ ပြန်လည်ပြောပြတဲ့အခါ သုံးပါတယ်။ များသောအားဖြင့် Present Tense ကို Past Tense ပြောင်းပေးရပါတယ်။",
    relatedQuizLevel: 5,
    examples: [
      { english: "Direct: 'I am happy.' -> Reported: He said he was happy.", myanmar: "သူက 'ငါ ပျော်တယ်' လို့ပြောတယ်။ -> သူပျော်နေတယ်လို့ သူပြောခဲ့တယ်။" }
    ],
    commonMistakes: [
      { wrong: "He said me he was tired.", right: "He told me he was tired.", reason: "Use 'told' with an object (me, him, her). Use 'said' without an object." }
    ],
    tips: [
      "Words like 'here' change to 'there', and 'today' changes to 'that day'."
    ],
    practice: [
      {
        id: "h23_1",
        question: "Direct: 'I like pizza.' -> Reported: She said she ___ pizza.",
        options: ["likes", "liked", "will like"],
        correctIndex: 1,
        explanation: "In reported speech, Present Simple changes to Past Simple."
      }
    ]
  },
  "h-relative-clauses": {
    id: "h-relative-clauses",
    title: "24. Relative Clauses (Who, Which, That)",
    category: "Advanced",
    difficulty: "Advanced",
    description: "Adding information to nouns.",
    explanation: "Relative clauses give extra information about a noun. Use 'who' for people and 'which' or 'that' for things.",
    summary: "Noun + Who/Which + Extra Info.",
    myanmarExplanation: "နာမ်တစ်ခုအကြောင်းကို အသေးစိတ် ထပ်လောင်းဖော်ပြချင်တဲ့အခါ သုံးပါတယ်။ လူဆိုရင် 'who' သုံးပြီး အရာဝတ္ထုဆိုရင် 'which/that' သုံးပါတယ်။",
    relatedQuizLevel: 5,
    examples: [
      { english: "The man who lives next door is a doctor.", myanmar: "ဘေးအိမ်မှာနေတဲ့လူက ဆရာဝန်တစ်ယောက်ပါ။" },
      { english: "The book that I bought is good.", myanmar: "ကျွန်တော်ဝယ်ခဲ့တဲ့စာအုပ်က ကောင်းတယ်။" }
    ],
    commonMistakes: [
      { wrong: "The car who I like is red.", right: "The car which I like is red.", reason: "Don't use 'who' for objects." }
    ],
    tips: [
      "Relative clauses help you combine two sentences into one longer, better sentence."
    ],
    practice: [
      {
        id: "h24_1",
        question: "That's the girl ___ won the race.",
        options: ["who", "which", "whose"],
        correctIndex: 0,
        explanation: "Use 'who' for people."
      }
    ]
  }
};
