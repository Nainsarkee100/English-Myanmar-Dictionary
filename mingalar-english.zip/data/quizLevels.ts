import { QuizLevel } from "../types";

export const QUIZ_LEVELS: QuizLevel[] = [
  {
    "level": 1,
    "questions": [
      {
        "question": "Which of the following is a greeting used in the morning?",
        "options": ["Good night", "Good afternoon", "Good morning", "Goodbye"],
        "correct": 2,
        "explanation": "'Good morning' is used from sunrise until noon."
      },
      {
        "question": "What is the English word for 'မင်္ဂလာပါ'?",
        "options": ["Sorry", "Hello", "Please", "Thanks"],
        "correct": 1,
        "explanation": "'Hello' is the standard greeting in English."
      },
      {
        "question": "How do you say 'ကျေးဇူးတင်ပါတယ်' in English?",
        "options": ["I am sorry", "You are welcome", "Thank you", "Excuse me"],
        "correct": 2,
        "explanation": "'Thank you' is used to show gratitude."
      },
      {
        "question": "Which word is a fruit?",
        "options": ["Car", "Apple", "Pen", "Table"],
        "correct": 1,
        "explanation": "An apple is a common edible fruit."
      },
      {
        "question": "What color is the sky on a clear day?",
        "options": ["Green", "Red", "Blue", "Black"],
        "correct": 2,
        "explanation": "The sky usually appears blue during the day."
      },
      {
        "question": "Which word is a verb (action word)?",
        "options": ["Apple", "Eat", "Table", "Happy"],
        "correct": 1,
        "explanation": "'Eat' is an action we perform."
      }
    ]
  },
  {
    "level": 2,
    "questions": [
      {
        "question": "I have ___ orange in my bag.",
        "options": ["a", "an", "the", "no article"],
        "correct": 1,
        "explanation": "'Orange' starts with a vowel sound."
      },
      {
        "question": "They ___ my best friends.",
        "options": ["am", "is", "are", "be"],
        "correct": 2,
        "explanation": "Plural subject 'They' uses 'are'."
      },
      {
        "question": "___ is my sister.",
        "options": ["She", "He", "Him", "Her"],
        "correct": 0,
        "explanation": "Use the subject pronoun 'She' for a female."
      },
      {
        "question": "Please tell ___ the truth.",
        "options": ["I", "me", "my", "mine"],
        "correct": 1,
        "explanation": "Use the object pronoun 'me'."
      }
    ]
  },
  {
    "level": 3,
    "questions": [
      {
        "question": "She ___ her lunch right now.",
        "options": ["eats", "is eating", "eat", "ate"],
        "correct": 1,
        "explanation": "'Right now' indicates Present Continuous."
      },
      {
        "question": "My father ___ coffee every morning.",
        "options": ["drink", "drinks", "drinking", "is drink"],
        "correct": 1,
        "explanation": "Habits use Present Simple with 's' for singular subjects."
      },
      {
        "question": "Where are my keys? They are ___ the table.",
        "options": ["in", "at", "on", "into"],
        "correct": 2,
        "explanation": "On a surface uses 'on'."
      },
      {
        "question": "I ___ to Mandalay last month.",
        "options": ["go", "goes", "went", "gone"],
        "correct": 2,
        "explanation": "Past simple of 'go' is 'went'."
      }
    ]
  },
  {
    "level": 4,
    "questions": [
      {
        "question": "I ___ my keys. I can't find them anywhere!",
        "options": ["lost", "have lost", "lose", "am losing"],
        "correct": 1,
        "explanation": "Present perfect is used for recent actions with current results."
      },
      {
        "question": "You ___ see a doctor about that cough.",
        "options": ["should", "can", "must to", "should to"],
        "correct": 0,
        "explanation": "'Should' is used for giving advice."
      },
      {
        "question": "This car is ___ than that one.",
        "options": ["fast", "faster", "more fast", "fastest"],
        "correct": 1,
        "explanation": "Short adjectives use -er for comparison."
      },
      {
        "question": "If it rains tomorrow, we ___ at home.",
        "options": ["stay", "would stay", "will stay", "stayed"],
        "correct": 2,
        "explanation": "First conditional uses will + base verb."
      }
    ]
  },
  {
    "level": 5,
    "questions": [
      {
        "question": "My car ___ yesterday.",
        "options": ["was repaired", "repaired", "is repaired", "be repaired"],
        "correct": 0,
        "explanation": "Passive voice past needs 'was' + V3."
      },
      {
        "question": "He said that he ___ happy.",
        "options": ["is", "was", "will be", "be"],
        "correct": 1,
        "explanation": "Tense shifts back in reported speech."
      },
      {
        "question": "If I ___ rich, I would buy a boat.",
        "options": ["am", "will be", "was", "were"],
        "correct": 3,
        "explanation": "Second conditional uses 'were' for imaginary situations."
      },
      {
        "question": "He speaks English very ___.",
        "options": ["good", "well", "best", "goodly"],
        "correct": 1,
        "explanation": "'Well' is the adverb form of 'good'."
      }
    ]
  }
];
