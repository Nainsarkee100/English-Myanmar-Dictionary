
const CACHE_NAME = 'mingalar-pwa-v9';
const OFFLINE_URL = 'index.html';

const ASSETS_TO_CACHE = [
  './',
  './index.html',
  './metadata.json',
  './index.tsx',
  './App.tsx',
  './types.ts',
  './services/geminiService.ts',
  './services/storage.ts',
  './data/dictionaryData.ts',
  './data/grammarData.ts',
  './data/quizLevels.ts',
  './components/Navigation.tsx',
  './components/Home.tsx',
  './components/Dictionary.tsx',
  './components/Grammar.tsx',
  './components/Quiz.tsx',
  './components/Notes.tsx',
  './components/AITutor.tsx',
  './components/ErrorBoundary.tsx',
  './components/Onboarding.tsx',
  'https://cdn.tailwindcss.com',
  'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Padauk:wght@400;700&family=Caveat:wght@700&display=swap'
];

const EXTERNAL_DEPS = [
  'https://esm.sh/react@^19.2.4',
  'https://esm.sh/react-dom@^19.2.4',
  'https://esm.sh/@google/genai@^1.41.0'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[SW] Pre-caching v9 assets');
      return cache.addAll([...ASSETS_TO_CACHE, ...EXTERNAL_DEPS]);
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.map((key) => {
        if (key !== CACHE_NAME) {
          console.log('[SW] Purging stale cache:', key);
          return caches.delete(key);
        }
      })
    ))
  );
  return self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);
  if (url.hostname.includes('generativelanguage.googleapis.com')) return;
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.match(OFFLINE_URL)));
    return;
  }
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      if (cachedResponse) return cachedResponse;
      return fetch(request).then((networkResponse) => {
        if (networkResponse && networkResponse.status === 200) {
          const clone = networkResponse.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
        }
        return networkResponse;
      }).catch(() => null);
    })
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});
