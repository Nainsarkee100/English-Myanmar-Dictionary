
import React, { useState, useEffect, useCallback, Suspense, lazy } from 'react';
import Navigation from './components/Navigation';
import ErrorBoundary from './components/ErrorBoundary';
import Onboarding from './components/Onboarding';
import AccessibilityControls from './components/AccessibilityControls';
import { View, AccessibilitySettings, FontSize } from './types';
import { getProgress, updateAccessibilitySettings as saveAccessibilitySettings } from './services/storage';

// Performance Optimization: Code-splitting all major views
const Home = lazy(() => import('./components/Home'));
const Dictionary = lazy(() => import('./components/Dictionary'));
const Grammar = lazy(() => import('./components/Grammar'));
const Quiz = lazy(() => import('./components/Quiz'));
const Notes = lazy(() => import('./components/Notes'));
const AITutor = lazy(() => import('./components/AITutor'));

// Lightweight loading component for Suspense
const ViewLoader = () => (
  <div className="flex flex-col items-center justify-center min-h-[400px] animate-pulse">
    <div className="w-12 h-12 bg-indigo-100 rounded-2xl mb-4"></div>
    <div className="h-4 w-32 bg-slate-100 rounded-full"></div>
  </div>
);

export default function App() {
  const [currentView, setCurrentView] = useState<View>('home');
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [viewParams, setViewParams] = useState<{ quizLevel?: number }>({});
  const [swUpdateRegistration, setSwUpdateRegistration] = useState<ServiceWorkerRegistration | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'error' | 'warning' | 'info' } | null>(null);
  const [showAccessibility, setShowAccessibility] = useState(false);
  
  const [accessibility, setAccessibility] = useState<AccessibilitySettings>({
    fontSize: 'medium',
    highContrast: false
  });

  useEffect(() => {
    const progress = getProgress();
    
    // Accessibility settings persistence
    if (progress.accessibility) {
      setAccessibility(progress.accessibility);
    }

    const updateOnlineStatus = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);

    const handleUpdateAvailable = (event: any) => setSwUpdateRegistration(event.detail);
    window.addEventListener('swUpdateAvailable', handleUpdateAvailable);

    const handleAppMessage = (event: any) => {
      setToast(event.detail);
      setTimeout(() => setToast(null), 5000);
    };
    window.addEventListener('appMessage', handleAppMessage);

    if (navigator.serviceWorker) {
      navigator.serviceWorker.addEventListener('controllerchange', () => window.location.reload());
    }

    return () => {
      window.removeEventListener('online', updateOnlineStatus);
      window.removeEventListener('offline', updateOnlineStatus);
      window.removeEventListener('swUpdateAvailable', handleUpdateAvailable);
      window.removeEventListener('appMessage', handleAppMessage);
    };
  }, []);

  const handleApplyUpdate = useCallback(() => {
    if (swUpdateRegistration?.waiting) {
      swUpdateRegistration.waiting.postMessage('SKIP_WAITING');
      setSwUpdateRegistration(null);
    }
  }, [swUpdateRegistration]);

  const handleSetView = useCallback((view: View, params: { quizLevel?: number } = {}) => {
    setCurrentView(view);
    setViewParams(params);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const completeOnboarding = () => {
    localStorage.setItem('nsk_onboarded_v1', 'true');
    setShowOnboarding(false);
  };

  const updateAccessibility = (newSettings: AccessibilitySettings) => {
    setAccessibility(newSettings);
    saveAccessibilitySettings(newSettings);
  };

  const renderView = () => {
    return (
      <Suspense fallback={<ViewLoader />}>
        {currentView === 'home' && <Home setView={handleSetView} />}
        {currentView === 'dictionary' && <Dictionary />}
        {currentView === 'grammar' && <Grammar onNavigateToQuiz={(level) => handleSetView('quiz', { quizLevel: level })} />}
        {currentView === 'quiz' && <Quiz initialLevel={viewParams.quizLevel} />}
        {currentView === 'tutor' && <AITutor />}
        {currentView === 'notes' && <Notes />}
      </Suspense>
    );
  };

  const fontSizeClass = `font-size-${accessibility.fontSize}`;
  const contrastClass = accessibility.highContrast ? 'high-contrast' : '';

  return (
    <ErrorBoundary>
      <div className={`min-h-screen flex flex-col bg-slate-50 font-sans selection:bg-indigo-100 antialiased transition-colors duration-500 ${fontSizeClass} ${contrastClass}`}>
        
        {showOnboarding && <Onboarding onComplete={completeOnboarding} />}

        {swUpdateRegistration && (
          <div className="bg-indigo-600 text-white py-3 px-6 flex items-center justify-between animate-in slide-in-from-top duration-500 sticky top-0 z-[100] shadow-2xl">
            <div className="flex items-center gap-3">
              <span className="text-xl">✨</span>
              <p className="text-xs font-black uppercase tracking-widest">New version available!</p>
            </div>
            <button onClick={handleApplyUpdate} className="bg-white text-indigo-600 px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest shadow-lg active:scale-95 transition-all">
              Update Now
            </button>
          </div>
        )}

        {toast && (
          <div className={`fixed bottom-24 left-1/2 -translate-x-1/2 z-[150] px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-4 animate-in slide-in-from-bottom-10 duration-500 max-w-[90vw] md:max-w-md ${
            toast.type === 'error' ? 'bg-rose-600 text-white' : toast.type === 'warning' ? 'bg-amber-500 text-white' : 'bg-slate-900 text-white'
          }`}>
            <p className="text-sm font-bold flex-1">{toast.message}</p>
            <button onClick={() => setToast(null)} className="opacity-60 font-black">✕</button>
          </div>
        )}

        <div className={`transition-all duration-500 overflow-hidden ${isOnline ? 'h-0' : 'h-10'}`}>
          <div className="bg-amber-500 text-white text-[10px] font-black uppercase tracking-widest flex items-center justify-center h-full gap-2 px-4 shadow-inner">
            <span className="animate-pulse text-sm">📡</span> Working Offline
          </div>
        </div>

        <Navigation 
          currentView={currentView} 
          setView={handleSetView} 
          onOpenSettings={() => setShowAccessibility(true)}
        />
        
        {showAccessibility && (
          <AccessibilityControls 
            settings={accessibility} 
            onUpdate={updateAccessibility} 
            onClose={() => setShowAccessibility(false)}
          />
        )}

        <main className="flex-1 w-full max-w-screen-xl mx-auto safe-bottom pb-24 md:pb-12">
          <div className="view-transition">{renderView()}</div>
        </main>
      </div>
    </ErrorBoundary>
  );
}
