
import { GoogleGenAI, Type } from "@google/genai";
import { DictionaryResult } from "../types";

const AI_TIMEOUT_MS = 15000;
const MAX_RETRIES = 2;

/**
 * Enhanced fetch with timeout to prevent UI hanging
 */
async function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  let timeoutId: number;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timeoutId = window.setTimeout(() => reject(new Error("TIMEOUT_ERROR")), timeoutMs);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timeoutId));
}

/**
 * Retry wrapper with exponential backoff
 */
async function withRetry<T>(
  fn: () => Promise<T>, 
  retries: number = MAX_RETRIES, 
  delay: number = 1000
): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const errorMessage = error?.message || "";
    
    // Do not retry if the error suggests it's a configuration issue that won't resolve
    if (errorMessage.includes("Requested entity was not found")) {
      throw new Error("KEY_RESET_REQUIRED");
    }
    
    if (retries <= 0) throw error;
    
    console.log(`[AI] Retrying... (${retries} attempts left)`);
    await new Promise(resolve => setTimeout(resolve, delay));
    return withRetry(fn, retries - 1, delay * 2);
  }
}

export const dictionaryLookup = async (word: string): Promise<DictionaryResult> => {
  if (!navigator.onLine) throw new Error("OFFLINE");

  return withRetry(async () => {
    // Always create a new instance right before call for fresh API key access
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const response = await withTimeout(
      ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Provide dictionary entry for: "${word}". Include Myanmar translation. Focus on ESL students.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              word: { type: Type.STRING },
              phonetic: { type: Type.STRING },
              myanmarMeaning: { type: Type.STRING },
              definition: { type: Type.STRING },
              examples: { type: Type.ARRAY, items: { type: Type.STRING } },
              synonyms: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["word", "myanmarMeaning", "definition"]
          }
        }
      }),
      AI_TIMEOUT_MS
    );

    const text = response.text;
    if (!text) throw new Error("EMPTY_RESPONSE");
    return JSON.parse(text);
  });
};

export const getGrammarExplanation = async (topic: string): Promise<string> => {
  if (!navigator.onLine) return "Offline. Using pre-saved explanations.";

  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await withTimeout(
      ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Explain "${topic}" English grammar for Myanmar students. Use Markdown. Provide simple translations.`,
      }),
      AI_TIMEOUT_MS
    );
    return response.text || "Could not generate explanation.";
  });
};

export const chatWithTutor = async (history: any[], message: string): Promise<string> => {
  if (!navigator.onLine) return "I'm offline. Let's study the words we already saved!";

  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const chat = ai.chats.create({
      model: 'gemini-3-pro-preview',
      history: history,
      config: {
        systemInstruction: "You are Mingalar, a supportive English tutor for students in Myanmar. Keep English simple. Occasionally use Myanmar phrases to encourage them.",
      },
    });

    const response = await withTimeout(chat.sendMessage({ message }), AI_TIMEOUT_MS);
    return response.text || "I'm a bit confused. Can you say that again?";
  });
};
