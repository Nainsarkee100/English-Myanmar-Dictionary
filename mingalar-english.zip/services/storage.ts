
import { DictionaryResult, UserProgress, UserNote, GrammarLesson, ActivityEntry, AccessibilitySettings } from "../types";
import { PRESEEDED_WORDS } from "../data/dictionaryData";
import { RICH_GRAMMAR_LESSONS } from "../data/grammarData";

const STORAGE_VERSION = 6;
const KEYS = {
  DICT: `nsk_dict_v${STORAGE_VERSION}`,
  PROGRESS: `nsk_progress_v${STORAGE_VERSION}`,
  NOTES: `nsk_notes_v${STORAGE_VERSION}`,
};

const reportAppError = (message: string, type: 'error' | 'warning' = 'error') => {
  window.dispatchEvent(new CustomEvent('appMessage', { 
    detail: { message, type } 
  }));
};

class GrammarIndex {
  private static lessons: Map<string, GrammarLesson> = new Map();
  private static metadata: { id: string; title: string; category: string; difficulty: string; order: number }[] = [];
  private static initialized = false;

  static initialize() {
    if (this.initialized) return;
    try {
      Object.entries(RICH_GRAMMAR_LESSONS).forEach(([id, lesson]) => {
        this.lessons.set(id, lesson);
        this.metadata.push({
          id: lesson.id,
          title: lesson.title,
          category: lesson.category,
          difficulty: lesson.difficulty,
          order: parseInt(lesson.title.split('.')[0]) || 99
        });
      });
      this.metadata.sort((a, b) => a.order - b.order);
      this.initialized = true;
    } catch (e) {
      reportAppError("Failed to load grammar lessons.");
    }
  }

  static getMetadata(filter: 'All' | 'Primary' | 'Middle' | 'High' = 'All') {
    if (!this.initialized) this.initialize();
    if (filter === 'All') return this.metadata;
    const difficultyMap: Record<string, string> = {
      'Beginner': 'Primary',
      'Intermediate': 'Middle',
      'Advanced': 'High'
    };
    return this.metadata.filter(m => difficultyMap[m.difficulty] === filter);
  }

  static getLesson(id: string): GrammarLesson | null {
    if (!this.initialized) this.initialize();
    return this.lessons.get(id) || null;
  }

  static getTotalCount() {
    if (!this.initialized) this.initialize();
    return this.metadata.length;
  }
}

class DictionaryIndex {
  private static instance: Map<string, DictionaryResult> = new Map();
  private static sortedKeys: string[] = [];
  private static initialized = false;

  static initialize() {
    if (this.initialized) return;
    Object.entries(PRESEEDED_WORDS).forEach(([key, val]) => {
      this.instance.set(key.toLowerCase().trim(), { ...val, isOffline: true });
    });
    const raw = localStorage.getItem(KEYS.DICT);
    if (raw) {
      try {
        const cache = JSON.parse(raw);
        Object.entries(cache).forEach(([key, val]) => {
          if (!this.instance.has(key)) {
            this.instance.set(key.toLowerCase().trim(), { ...(val as DictionaryResult), isOffline: true });
          }
        });
      } catch (e) {
        localStorage.removeItem(KEYS.DICT);
      }
    }
    this.rebuildSortedKeys();
    this.initialized = true;
  }

  private static rebuildSortedKeys() {
    this.sortedKeys = Array.from(this.instance.keys()).sort();
  }

  static getExact(word: string): DictionaryResult | null {
    if (!this.initialized) this.initialize();
    return this.instance.get(word.toLowerCase().trim()) || null;
  }

  static getPrefixMatches(prefix: string, limit: number = 8): string[] {
    if (!this.initialized) this.initialize();
    const query = prefix.toLowerCase().trim();
    if (!query) return [];
    let low = 0, high = this.sortedKeys.length - 1, firstIndex = -1;
    while (low <= high) {
      const mid = Math.floor((low + high) / 2);
      if (this.sortedKeys[mid] >= query) { firstIndex = mid; high = mid - 1; }
      else low = mid + 1;
    }
    if (firstIndex === -1) return [];
    const matches: string[] = [];
    for (let i = firstIndex; i < this.sortedKeys.length && matches.length < limit; i++) {
      if (this.sortedKeys[i].startsWith(query)) matches.push(this.sortedKeys[i]);
      else break;
    }
    return matches;
  }

  static add(result: DictionaryResult) {
    if (!this.initialized) this.initialize();
    const wordKey = result.word.toLowerCase().trim();
    this.instance.set(wordKey, { ...result, isOffline: true });
    this.rebuildSortedKeys();
    const storageObj: Record<string, DictionaryResult> = {};
    this.instance.forEach((val, key) => { if (!PRESEEDED_WORDS[key]) storageObj[key] = val; });
    try {
      localStorage.setItem(KEYS.DICT, JSON.stringify(storageObj));
    } catch (e: any) {
      if (e.name === 'QuotaExceededError') reportAppError("Storage full.", "warning");
    }
  }

  static getAllKeys(): string[] {
    if (!this.initialized) this.initialize();
    return this.sortedKeys;
  }
}

export const getProgress = (): UserProgress => {
  const today = new Date().toISOString().split('T')[0];
  const defaultProgress: UserProgress = {
    wordsLearned: 0,
    streak: 0,
    lastActive: today,
    grammarCompleted: [],
    quizLevelsCompleted: [],
    quizScores: {},
    totalPoints: 0,
    history: [],
    version: STORAGE_VERSION,
    accessibility: {
      fontSize: 'medium',
      highContrast: false
    }
  };

  const p = safeParse<UserProgress>(KEYS.PROGRESS, defaultProgress);
  
  // Streak Logic
  if (p.lastActive !== today) {
    const last = new Date(p.lastActive);
    const curr = new Date(today);
    const diffDays = Math.floor((curr.getTime() - last.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) p.streak += 1;
    else if (diffDays > 1) p.streak = 1;
    
    p.lastActive = today;
    safeSave(KEYS.PROGRESS, p);
  } else if (p.streak === 0) {
    p.streak = 1;
    safeSave(KEYS.PROGRESS, p);
  }
  
  return p;
};

const safeParse = <T>(key: string, fallback: T): T => {
  try {
    const data = localStorage.getItem(key);
    if (!data) return fallback;
    return JSON.parse(data) as T;
  } catch (e) {
    return fallback;
  }
};

const safeSave = (key: string, data: any) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e: any) {
    if (e.name === 'QuotaExceededError') reportAppError("Storage full.", "warning");
  }
};

const logActivity = (progress: UserProgress, entry: Omit<ActivityEntry, 'timestamp'>) => {
  const fullEntry: ActivityEntry = { ...entry, timestamp: new Date().toISOString() };
  progress.history = [fullEntry, ...progress.history.slice(0, 14)]; // Keep last 15
};

export const updateAccessibilitySettings = (settings: AccessibilitySettings) => {
  const p = getProgress();
  p.accessibility = settings;
  safeSave(KEYS.PROGRESS, p);
};

export const markGrammarAsCompleted = (lessonId: string, title: string) => {
  const p = getProgress();
  if (!p.grammarCompleted.includes(lessonId)) {
    p.grammarCompleted.push(lessonId);
    p.totalPoints += 50;
    logActivity(p, { type: 'grammar', id: lessonId, label: `Mastered ${title}` });
    safeSave(KEYS.PROGRESS, p);
  }
};

export const completeQuizLevel = (level: number, score: number, totalQuestions: number) => {
  const p = getProgress();
  const percentage = Math.round((score / totalQuestions) * 100);
  
  if (!p.quizLevelsCompleted.includes(level)) p.quizLevelsCompleted.push(level);
  
  const previousBest = p.quizScores[level] || 0;
  if (percentage > previousBest) {
    p.quizScores[level] = percentage;
  }
  
  p.totalPoints += score * 5;
  logActivity(p, { type: 'quiz', id: level.toString(), label: `Quiz Level ${level}`, score: percentage });
  safeSave(KEYS.PROGRESS, p);
};

export const saveToDictionaryCache = (result: DictionaryResult) => {
  DictionaryIndex.add(result);
  const p = getProgress();
  p.wordsLearned++;
  p.totalPoints += 10;
  logActivity(p, { type: 'word', id: result.word, label: `Looked up ${result.word}` });
  safeSave(KEYS.PROGRESS, p);
};

export const getDictionaryFromCache = (word: string) => DictionaryIndex.getExact(word);
export const getPrefixSuggestions = (prefix: string, limit: number = 8) => DictionaryIndex.getPrefixMatches(prefix, limit);
export const getGrammarMetadata = (filter?: any) => GrammarIndex.getMetadata(filter);
export const getGrammarLessonById = (id: string) => GrammarIndex.getLesson(id);
export const getTotalGrammarCount = () => GrammarIndex.getTotalCount();
export const updatePointProgress = (points: number) => {
  const p = getProgress();
  p.totalPoints += points;
  safeSave(KEYS.PROGRESS, p);
};
export const getNotes = (): UserNote[] => safeParse<UserNote[]>(KEYS.NOTES, []);
export const saveNote = (note: UserNote) => {
  const notes = getNotes();
  const index = notes.findIndex(n => n.id === note.id);
  if (index >= 0) notes[index] = note; else notes.unshift(note);
  safeSave(KEYS.NOTES, notes);
};
export const deleteNote = (id: string) => safeSave(KEYS.NOTES, getNotes().filter(n => n.id !== id));
export const getAllOfflineWords = (): string[] => DictionaryIndex.getAllKeys();
